MDetect Robot ROS2 Humble Workspace - Pi IMU + Arduino Encoder/Motor Architecture
===============================================================================

New architecture:

Arduino:
- Reads four wheel encoders.
- Runs motor speed PID.
- Waits for velocity commands from Raspberry Pi.
- Prints encoder ticks only.
- Does NOT use MPU6050 anymore.

Raspberry Pi:
- Reads MPU9250 / MPU6500 / MPU9255 by I2C.
- Reads COIN-D6 LiDAR by USB serial.
- Calculates odometry using encoders + Pi IMU yaw.
- Builds map and cost map.
- Plans route and runs pure pursuit.
- Sends velocity commands to Arduino.

Install dependencies:
sudo apt update
sudo apt install -y python3-pip python3-serial python3-smbus i2c-tools
python3 -m pip install pyserial smbus2 --break-system-packages

Enable I2C:
sudo raspi-config
Interface Options > I2C > Enable
sudo reboot

Check devices:
ls /dev/ttyUSB*
i2cdetect -y 1

Build:
cd ~/mdetect_robot_pi_imu_ros2_ws
source /opt/ros/humble/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash

Run:
ros2 launch mdetect_robot mdetect_robot_pi_imu.launch.py

Send goal:
ros2 run mdetect_robot goal_sender --ros-args -p x:=1.0 -p y:=1.0

Emergency stop:
ros2 topic pub /emergency_stop std_msgs/Bool "{data: true}" --once

Reset Arduino:
ros2 topic pub /reset_arduino std_msgs/Bool "{data: true}" --once

Reset encoder count:
ros2 topic pub /reset_encoders std_msgs/Bool "{data: true}" --once
