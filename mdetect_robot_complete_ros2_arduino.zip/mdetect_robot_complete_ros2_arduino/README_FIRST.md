# MDetect Robot - ROS2 Humble + Raspberry Pi 4B + Arduino Motor Controller

This workspace uses the new architecture:

## Arduino Uno / Mega
- Reads 4 wheel encoders.
- Runs motor speed PID.
- Drives the QGPMaker motor shield.
- Waits for serial velocity commands from Raspberry Pi.
- Prints encoder ticks only.
- MPU6050 is no longer used on Arduino.

## Raspberry Pi 4B
- Runs ROS2 Humble robot nodes.
- Reads MPU9250 / MPU6500 / MPU9255 through I2C.
- Reads COIN-D6 LiDAR through USB serial.
- Reads encoder ticks from Arduino.
- Calculates X, Y, and yaw odometry.
- Builds occupancy map + cost map.
- Runs A* route planning and pure pursuit.
- Sends `CMD,right_mm_s,forward_mm_s,yaw_deg_s` to Arduino.
- Sends emergency stop if front obstacle distance is below 300 mm.

## Ubuntu laptop / desktop
- Runs RViz for visualising `/odom`, `/scan`, `/map`, `/costmap`, `/planned_path`, and `/route_points`.
- Can also send target goals.

---

## Folder structure

```text
mdetect_robot_complete_ros2_arduino/
├── src/mdetect_robot/                         # ROS2 Humble package
├── Arduino_IDE_Project/arduino_encoder_motor_controller/
│   ├── arduino_encoder_motor_controller.ino   # Arduino code
│   └── required QGPMaker / PinChangeInterrupt libraries
├── install/                                   # helper scripts
└── docs/                                      # serial protocol and notes
```

---

## 1. Upload Arduino code

Open this folder in Arduino IDE:

```text
Arduino_IDE_Project/arduino_encoder_motor_controller/
```

Upload:

```text
arduino_encoder_motor_controller.ino
```

Default serial:

```text
Baud: 500000
Output: ENC,time_ms,fl_ticks,fr_ticks,rl_ticks,rr_ticks
Input:  CMD,right_mm_s,forward_mm_s,yaw_deg_s
```

---

## 2. Raspberry Pi 4B setup

Copy the whole workspace to the Pi, then run:

```bash
cd ~/mdetect_robot_complete_ros2_arduino
chmod +x install/*.sh
./install/pi4b_install_dependencies.sh
./install/build_workspace.sh
```

Enable I2C:

```bash
sudo raspi-config
# Interface Options > I2C > Enable
sudo reboot
```

Check ports and IMU:

```bash
ls /dev/ttyUSB*
i2cdetect -y 1
```

Expected default ports:

```text
Arduino: /dev/ttyUSB0, 500000 baud
COIN-D6 LiDAR: /dev/ttyUSB1, 230400 baud
MPU9250/6500/9255: 0x68 or 0x69
```

Run robot nodes on Pi:

```bash
cd ~/mdetect_robot_complete_ros2_arduino
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch mdetect_robot mdetect_robot_pi_imu.launch.py
```

---

## 3. Ubuntu RViz setup

```bash
cd ~/mdetect_robot_complete_ros2_arduino
chmod +x install/*.sh
./install/ubuntu_install_dependencies.sh
./install/build_workspace.sh
```

Use the same ROS domain on both Ubuntu and Raspberry Pi:

```bash
export ROS_DOMAIN_ID=30
```

Run RViz:

```bash
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch mdetect_robot ubuntu_rviz.launch.py
```

---

## 4. Send a goal

```bash
ros2 run mdetect_robot goal_sender --ros-args -p x:=1.0 -p y:=1.0
```

Units are metres.

---

## 5. Emergency stop and reset

Emergency stop:

```bash
ros2 topic pub /emergency_stop std_msgs/Bool "{data: true}" --once
```

Release emergency stop:

```bash
ros2 topic pub /emergency_stop std_msgs/Bool "{data: false}" --once
```

Reset Arduino through USB DTR:

```bash
ros2 topic pub /reset_arduino std_msgs/Bool "{data: true}" --once
```

Reset encoders:

```bash
ros2 topic pub /reset_encoders std_msgs/Bool "{data: true}" --once
```

---

## 6. Main tuning file

Edit:

```text
src/mdetect_robot/config/robot_params.yaml
```

Important values:

```yaml
coin_d6_lidar:
  ros__parameters:
    angle_offset_deg: 0.0

occupancy_mapper:
  ros__parameters:
    robot_radius_m: 0.20       # 200 mm robot radius from centre
    extra_clearance_m: 0.05    # 50 mm extra clearance

safety_stop:
  ros__parameters:
    front_stop_distance_m: 0.30 # 300 mm safety stop
```
