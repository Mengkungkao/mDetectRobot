/*
  MDetect Arduino Encoder + Motor Controller

  Arduino role:
  - Reads four encoders.
  - Runs wheel speed PID.
  - Waits for velocity command from Raspberry Pi.
  - Prints encoder ticks only.
  - No MPU6050 is used on Arduino.

  Commands from Raspberry Pi:
    CMD,right_mm_s,forward_mm_s,yaw_deg_s
    STOP:
    RESET_ENC:
    PING:

  Encoder output:
    ENC,time_ms,fl_ticks,fr_ticks,rl_ticks,rr_ticks
*/

#include <Wire.h>
#include "QGPMaker_MotorShield.h"
#include "QGPMaker_Encoder.h"

const unsigned long SERIAL_BAUD = 500000;
const float WHEEL_DIAMETER_MM = 80.5;
const float WHEEL_CIRC_MM = WHEEL_DIAMETER_MM * 3.1415926;
const float TICKS_PER_REV = 4320.0;
const float HALF_LENGTH_MM = 150.0;
const float HALF_WIDTH_MM  = 100.0;
const float MECANUM_K_MM = HALF_LENGTH_MM + HALF_WIDTH_MM;

const unsigned long CONTROL_PERIOD_MS = 20;
const unsigned long PRINT_PERIOD_MS = 50;
const unsigned long COMMAND_TIMEOUT_MS = 500;

float KP = 0.020;
float KI = 0.0008;
float KD = 0.0005;
float FF = 0.020;

const int MAX_PWM = 180;
const int MIN_ACTIVE_PWM = 35;
const float STOP_TICKS_PER_SEC = 15.0;

int MOTOR_SIGN_FL =  1;
int MOTOR_SIGN_FR =  1;
int MOTOR_SIGN_RL =  1;
int MOTOR_SIGN_RR =  1;

int ENC_SIGN_FL =  1;
int ENC_SIGN_FR =  1;
int ENC_SIGN_RL =  1;
int ENC_SIGN_RR =  1;

QGPMaker_MotorShield motorShield = QGPMaker_MotorShield();
QGPMaker_DCMotor *motorFL = motorShield.getMotor(1);
QGPMaker_DCMotor *motorFR = motorShield.getMotor(2);
QGPMaker_DCMotor *motorRL = motorShield.getMotor(3);
QGPMaker_DCMotor *motorRR = motorShield.getMotor(4);

QGPMaker_Encoder encFL(1);
QGPMaker_Encoder encFR(2);
QGPMaker_Encoder encRL(3);
QGPMaker_Encoder encRR(4);

struct WheelPID {
  float targetTicksPerSec;
  float measuredTicksPerSec;
  float integral;
  float prevError;
  long prevTicks;
  int pwm;
};

WheelPID pidFL = {0,0,0,0,0,0};
WheelPID pidFR = {0,0,0,0,0,0};
WheelPID pidRL = {0,0,0,0,0,0};
WheelPID pidRR = {0,0,0,0,0,0};

unsigned long lastControlMs = 0;
unsigned long lastPrintMs = 0;
unsigned long lastCommandMs = 0;
String serialLine = "";
bool stopped = true;

long readFL() { return encFL.read() * ENC_SIGN_FL; }
long readFR() { return encFR.read() * ENC_SIGN_FR; }
long readRL() { return encRL.read() * ENC_SIGN_RL; }
long readRR() { return encRR.read() * ENC_SIGN_RR; }

void runSigned(QGPMaker_DCMotor *motor, int signedPwm, int motorSign) {
  signedPwm *= motorSign;
  int pwm = abs(signedPwm);
  if (pwm > MAX_PWM) pwm = MAX_PWM;
  if (pwm < MIN_ACTIVE_PWM) {
    motor->setSpeed(0);
    motor->run(RELEASE);
    return;
  }
  motor->setSpeed(pwm);
  if (signedPwm >= 0) motor->run(FORWARD);
  else motor->run(BACKWARD);
}

void stopMotors() {
  pidFL.targetTicksPerSec = 0;
  pidFR.targetTicksPerSec = 0;
  pidRL.targetTicksPerSec = 0;
  pidRR.targetTicksPerSec = 0;
  pidFL.integral = pidFR.integral = pidRL.integral = pidRR.integral = 0;
  pidFL.prevError = pidFR.prevError = pidRL.prevError = pidRR.prevError = 0;
  motorFL->setSpeed(0); motorFL->run(RELEASE);
  motorFR->setSpeed(0); motorFR->run(RELEASE);
  motorRL->setSpeed(0); motorRL->run(RELEASE);
  motorRR->setSpeed(0); motorRR->run(RELEASE);
  stopped = true;
}

float mmPerSecToTicksPerSec(float mmPerSec) {
  return (mmPerSec / WHEEL_CIRC_MM) * TICKS_PER_REV;
}

void setBodyVelocity(float rightMmS, float forwardMmS, float yawDegS) {
  float omegaRadS = yawDegS * 3.1415926 / 180.0;
  float flMmS = forwardMmS + rightMmS - MECANUM_K_MM * omegaRadS;
  float frMmS = forwardMmS - rightMmS + MECANUM_K_MM * omegaRadS;
  float rlMmS = forwardMmS - rightMmS - MECANUM_K_MM * omegaRadS;
  float rrMmS = forwardMmS + rightMmS + MECANUM_K_MM * omegaRadS;
  pidFL.targetTicksPerSec = mmPerSecToTicksPerSec(flMmS);
  pidFR.targetTicksPerSec = mmPerSecToTicksPerSec(frMmS);
  pidRL.targetTicksPerSec = mmPerSecToTicksPerSec(rlMmS);
  pidRR.targetTicksPerSec = mmPerSecToTicksPerSec(rrMmS);
  lastCommandMs = millis();
  stopped = false;
}

int updatePID(WheelPID &pid, long currentTicks, float dtSec) {
  long deltaTicks = currentTicks - pid.prevTicks;
  pid.prevTicks = currentTicks;
  pid.measuredTicksPerSec = deltaTicks / dtSec;
  if (abs(pid.targetTicksPerSec) < STOP_TICKS_PER_SEC) {
    pid.integral = 0;
    pid.prevError = 0;
    pid.pwm = 0;
    return 0;
  }
  float error = pid.targetTicksPerSec - pid.measuredTicksPerSec;
  pid.integral += error * dtSec;
  pid.integral = constrain(pid.integral, -3000.0, 3000.0);
  float derivative = (error - pid.prevError) / dtSec;
  pid.prevError = error;
  float signedPwm = FF * pid.targetTicksPerSec + KP * error + KI * pid.integral + KD * derivative;
  signedPwm = constrain(signedPwm, -MAX_PWM, MAX_PWM);
  pid.pwm = (int)signedPwm;
  return pid.pwm;
}

void handleCommand(String line) {
  line.trim();
  if (line.length() == 0) return;
  if (line == "STOP:") {
    stopMotors();
    Serial.println("STOPPED");
    return;
  }
  if (line == "RESET_ENC:") {
    encFL.write(0);
    encFR.write(0);
    encRL.write(0);
    encRR.write(0);
    pidFL.prevTicks = pidFR.prevTicks = pidRL.prevTicks = pidRR.prevTicks = 0;
    Serial.println("OK,RESET_ENC");
    return;
  }
  if (line == "PING:") {
    Serial.println("PONG");
    return;
  }
  if (line.startsWith("CMD,")) {
    int c1 = line.indexOf(',');
    int c2 = line.indexOf(',', c1 + 1);
    int c3 = line.indexOf(',', c2 + 1);
    if (c1 < 0 || c2 < 0 || c3 < 0) {
      Serial.println("ERR,BAD_CMD");
      return;
    }
    float rightMmS = line.substring(c1 + 1, c2).toFloat();
    float forwardMmS = line.substring(c2 + 1, c3).toFloat();
    float yawDegS = line.substring(c3 + 1).toFloat();
    setBodyVelocity(rightMmS, forwardMmS, yawDegS);
    Serial.println("OK,CMD");
    return;
  }
  Serial.println("ERR,UNKNOWN_CMD");
}

void readSerialNonBlocking() {
  while (Serial.available() > 0) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (serialLine.length() > 0) {
        handleCommand(serialLine);
        serialLine = "";
      }
    } else {
      if (serialLine.length() < 80) serialLine += ch;
      else serialLine = "";
    }
  }
}

void printEncoderLine() {
  Serial.print("ENC,");
  Serial.print(millis());
  Serial.print(',');
  Serial.print(readFL());
  Serial.print(',');
  Serial.print(readFR());
  Serial.print(',');
  Serial.print(readRL());
  Serial.print(',');
  Serial.println(readRR());
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  motorShield.begin();
  stopMotors();
  delay(500);
  pidFL.prevTicks = readFL();
  pidFR.prevTicks = readFR();
  pidRL.prevTicks = readRL();
  pidRR.prevTicks = readRR();
  lastControlMs = millis();
  lastPrintMs = millis();
  lastCommandMs = millis();
  Serial.println("OK,MDETECT_ENCODER_MOTOR_CONTROLLER_READY");
}

void loop() {
  readSerialNonBlocking();
  unsigned long now = millis();
  if (!stopped && (now - lastCommandMs > COMMAND_TIMEOUT_MS)) {
    stopMotors();
    Serial.println("STOPPED,TIMEOUT");
  }
  if (now - lastControlMs >= CONTROL_PERIOD_MS) {
    float dtSec = (now - lastControlMs) / 1000.0;
    lastControlMs = now;
    runSigned(motorFL, updatePID(pidFL, readFL(), dtSec), MOTOR_SIGN_FL);
    runSigned(motorFR, updatePID(pidFR, readFR(), dtSec), MOTOR_SIGN_FR);
    runSigned(motorRL, updatePID(pidRL, readRL(), dtSec), MOTOR_SIGN_RL);
    runSigned(motorRR, updatePID(pidRR, readRR(), dtSec), MOTOR_SIGN_RR);
  }
  if (now - lastPrintMs >= PRINT_PERIOD_MS) {
    lastPrintMs = now;
    printEncoderLine();
  }
}
