# Arduino Serial Protocol

Baud rate: `500000`

## Commands from Raspberry Pi to Arduino

### Velocity command

```text
CMD,right_mm_s,forward_mm_s,yaw_deg_s
```

Examples:

```text
CMD,0,120,0       # move forward at 120 mm/s
CMD,120,0,0       # move right at 120 mm/s
CMD,0,0,30        # rotate CCW at 30 deg/s
CMD,0,0,0         # stop smoothly
```

### Emergency stop

```text
STOP:
```

### Reset encoder counts

```text
RESET_ENC:
```

### Ping test

```text
PING:
```

Arduino replies:

```text
PONG
```

## Data from Arduino to Raspberry Pi

Arduino prints encoder ticks as:

```text
ENC,time_ms,fl_ticks,fr_ticks,rl_ticks,rr_ticks
```

Example:

```text
ENC,10500,1234,1229,1231,1237
```

The Raspberry Pi calculates robot X/Y position from these encoder ticks and yaw from MPU9250/6500/9255.
