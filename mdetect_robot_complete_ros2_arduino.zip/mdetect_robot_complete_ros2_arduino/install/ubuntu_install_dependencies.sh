#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y   python3-pip python3-serial python3-smbus i2c-tools   ros-humble-rviz2 ros-humble-tf2-ros ros-humble-robot-state-publisher   ros-humble-xacro
python3 -m pip install --user pyserial smbus2 numpy
cat <<EOF

Done.
Use the same ROS_DOMAIN_ID on Ubuntu and Raspberry Pi, for example:
export ROS_DOMAIN_ID=30
EOF
