#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y   python3-pip python3-serial python3-smbus i2c-tools   ros-humble-rviz2 ros-humble-tf2-ros ros-humble-robot-state-publisher   ros-humble-xacro
python3 -m pip install --user pyserial smbus2 numpy
cat <<EOF

Done.
Next steps:
1) Enable I2C: sudo raspi-config
2) Reboot the Pi.
3) Check IMU: i2cdetect -y 1
4) Build: ./install/build_workspace.sh
EOF
