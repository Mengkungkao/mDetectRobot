#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
source /opt/ros/humble/setup.bash
source install/setup.bash
export ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-30}
ros2 launch mdetect_robot ubuntu_rviz.launch.py
