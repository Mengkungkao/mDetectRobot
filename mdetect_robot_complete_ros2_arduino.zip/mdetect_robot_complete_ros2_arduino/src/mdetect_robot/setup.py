from setuptools import setup
from glob import glob
import os

package_name = 'mdetect_robot'

setup(
    name=package_name,
    version='0.2.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Mengkung',
    maintainer_email='user@example.com',
    description='MDetect robot ROS2 Humble package with Pi IMU, Arduino encoders, COIN-D6 LiDAR, mapping, route planner, and pure pursuit.',
    license='MIT',
    entry_points={
        'console_scripts': [
            'arduino_motor_bridge = mdetect_robot.arduino_motor_bridge_node:main',
            'pi_imu = mdetect_robot.pi_imu_node:main',
            'mecanum_odometry = mdetect_robot.mecanum_odometry_node:main',
            'coin_d6_lidar = mdetect_robot.coin_d6_lidar_node:main',
            'safety_stop = mdetect_robot.safety_stop_node:main',
            'occupancy_mapper = mdetect_robot.occupancy_mapper_node:main',
            'route_planner = mdetect_robot.route_planner_node:main',
            'pure_pursuit = mdetect_robot.pure_pursuit_node:main',
            'goal_sender = mdetect_robot.goal_sender_node:main',
            'imu_print = mdetect_robot.imu_print_node:main',
        ],
    },
)
