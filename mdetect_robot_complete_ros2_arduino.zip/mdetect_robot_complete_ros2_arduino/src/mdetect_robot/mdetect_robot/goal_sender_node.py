import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped


class GoalSender(Node):
    def __init__(self):
        super().__init__('goal_sender')
        self.declare_parameter('x', 1.0)
        self.declare_parameter('y', 1.0)
        self.declare_parameter('frame_id', 'odom')
        self.pub = self.create_publisher(PoseStamped, 'goal_pose', 10)
        self.sent = False
        self.create_timer(0.5, self.timer_callback)

    def timer_callback(self):
        if self.sent:
            return
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.get_parameter('frame_id').value
        msg.pose.position.x = float(self.get_parameter('x').value)
        msg.pose.position.y = float(self.get_parameter('y').value)
        msg.pose.orientation.w = 1.0
        self.pub.publish(msg)
        self.get_logger().info(f'Sent goal x={msg.pose.position.x:.2f}, y={msg.pose.position.y:.2f}')
        self.sent = True


def main(args=None):
    rclpy.init(args=args)
    node = GoalSender()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
