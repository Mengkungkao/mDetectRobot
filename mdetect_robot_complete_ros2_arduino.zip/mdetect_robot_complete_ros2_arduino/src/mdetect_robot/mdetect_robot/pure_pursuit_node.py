import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool
from .utils import quaternion_to_yaw, wrap_angle, clamp


class PurePursuitNode(Node):
    def __init__(self):
        super().__init__('pure_pursuit')
        self.declare_parameter('lookahead_m', 0.35)
        self.declare_parameter('goal_tolerance_m', 0.12)
        self.declare_parameter('max_linear_m_s', 0.18)
        self.declare_parameter('min_linear_m_s', 0.05)
        self.declare_parameter('max_angular_rad_s', 0.8)
        self.declare_parameter('heading_gain', 1.5)
        self.declare_parameter('control_rate_hz', 20.0)
        self.declare_parameter('enable', True)
        self.lookahead = float(self.get_parameter('lookahead_m').value)
        self.goal_tol = float(self.get_parameter('goal_tolerance_m').value)
        self.max_linear = float(self.get_parameter('max_linear_m_s').value)
        self.min_linear = float(self.get_parameter('min_linear_m_s').value)
        self.max_angular = float(self.get_parameter('max_angular_rad_s').value)
        self.heading_gain = float(self.get_parameter('heading_gain').value)
        self.enabled = bool(self.get_parameter('enable').value)
        self.path = []
        self.pose = None
        self.progress_index = 0
        self.emergency_stop = False
        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.create_subscription(Path, 'planned_path', self.path_callback, 10)
        self.create_subscription(Odometry, 'odom', self.odom_callback, 20)
        self.create_subscription(Bool, 'emergency_stop', self.stop_callback, 10)
        self.create_timer(1.0 / max(1.0, float(self.get_parameter('control_rate_hz').value)), self.control_timer)

    def path_callback(self, path):
        self.path = [(p.pose.position.x, p.pose.position.y) for p in path.poses]
        self.progress_index = 0

    def odom_callback(self, odom):
        self.pose = (odom.pose.pose.position.x, odom.pose.pose.position.y, quaternion_to_yaw(odom.pose.pose.orientation))

    def stop_callback(self, msg):
        self.emergency_stop = bool(msg.data)
        if self.emergency_stop:
            self.publish_stop()

    def publish_stop(self):
        self.cmd_pub.publish(Twist())

    def control_timer(self):
        if not self.enabled or self.emergency_stop or self.pose is None or len(self.path) < 2:
            return
        x, y, yaw = self.pose
        goal_x, goal_y = self.path[-1]
        if math.hypot(goal_x - x, goal_y - y) <= self.goal_tol:
            self.publish_stop()
            return
        nearest_i = self.progress_index
        nearest_d = float('inf')
        for i in range(self.progress_index, min(len(self.path), self.progress_index + 30)):
            px, py = self.path[i]
            d = math.hypot(px - x, py - y)
            if d < nearest_d:
                nearest_i = i
                nearest_d = d
        self.progress_index = max(self.progress_index, nearest_i)
        target_i = len(self.path) - 1
        for i in range(self.progress_index, len(self.path)):
            px, py = self.path[i]
            if math.hypot(px - x, py - y) >= self.lookahead:
                target_i = i
                break
        tx, ty = self.path[target_i]
        heading_error = wrap_angle(math.atan2(ty - y, tx - x) - yaw)
        cmd = Twist()
        speed_scale = max(0.25, 1.0 - abs(heading_error) / math.pi)
        cmd.linear.x = clamp(self.max_linear * speed_scale, self.min_linear, self.max_linear)
        cmd.linear.y = 0.0
        cmd.angular.z = clamp(self.heading_gain * heading_error, -self.max_angular, self.max_angular)
        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = PurePursuitNode()
    try:
        rclpy.spin(node)
    finally:
        node.publish_stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
