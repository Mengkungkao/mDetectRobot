import math
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from std_msgs.msg import Float32, String

from .utils import yaw_to_quaternion, wrap_angle

try:
    from smbus2 import SMBus
except Exception:
    SMBus = None


class PiImuNode(Node):
    ACCEL_XOUT_H = 0x3B
    PWR_MGMT_1 = 0x6B
    CONFIG = 0x1A
    GYRO_CONFIG = 0x1B
    ACCEL_CONFIG = 0x1C
    INT_PIN_CFG = 0x37
    WHO_AM_I = 0x75

    def __init__(self):
        super().__init__('pi_imu')
        self.declare_parameter('i2c_bus', 1)
        self.declare_parameter('address', 0x68)
        self.declare_parameter('frame_id', 'imu_link')
        self.declare_parameter('publish_rate_hz', 100.0)
        self.declare_parameter('calibration_samples', 300)
        self.declare_parameter('gyro_z_offset_dps', 0.0)
        self.declare_parameter('yaw_offset_rad', 0.0)
        self.declare_parameter('auto_calibrate_gyro', True)

        self.i2c_bus = int(self.get_parameter('i2c_bus').value)
        self.address = int(self.get_parameter('address').value)
        self.frame_id = self.get_parameter('frame_id').value
        self.rate = float(self.get_parameter('publish_rate_hz').value)
        self.calibration_samples = int(self.get_parameter('calibration_samples').value)
        self.gyro_z_offset_dps = float(self.get_parameter('gyro_z_offset_dps').value)
        self.yaw = float(self.get_parameter('yaw_offset_rad').value)
        self.auto_calibrate_gyro = bool(self.get_parameter('auto_calibrate_gyro').value)

        self.gyro_scale = 250.0 / 32768.0
        self.accel_scale = 2.0 * 9.80665 / 32768.0
        self.bus = None
        self.last_time = time.monotonic()

        self.imu_pub = self.create_publisher(Imu, 'imu/data', 20)
        self.yaw_pub = self.create_publisher(Float32, 'imu/yaw', 20)
        self.status_pub = self.create_publisher(String, 'imu/status', 10)

        self.connect()
        if self.bus is not None and self.auto_calibrate_gyro:
            self.calibrate_gyro_z()

        self.create_timer(1.0 / max(1.0, self.rate), self.timer_callback)
        self.create_timer(1.0, self.status_timer_callback)

    def connect(self):
        if SMBus is None:
            self.get_logger().error('smbus2 is not installed. Install with: python3 -m pip install smbus2')
            return
        try:
            self.bus = SMBus(self.i2c_bus)
            self.write_u8(self.PWR_MGMT_1, 0x00)
            time.sleep(0.1)
            self.write_u8(self.CONFIG, 0x03)
            self.write_u8(self.GYRO_CONFIG, 0x00)
            self.write_u8(self.ACCEL_CONFIG, 0x00)
            self.write_u8(self.INT_PIN_CFG, 0x02)
            who = self.read_u8(self.WHO_AM_I)
            self.get_logger().info(f'MPU connected at 0x{self.address:02X}, WHO_AM_I=0x{who:02X}')
        except Exception as exc:
            self.bus = None
            self.get_logger().error(f'Failed to connect to IMU: {exc}')

    def read_u8(self, reg):
        return self.bus.read_byte_data(self.address, reg)

    def write_u8(self, reg, value):
        self.bus.write_byte_data(self.address, reg, value)

    def read_i16(self, reg):
        high = self.read_u8(reg)
        low = self.read_u8(reg + 1)
        value = (high << 8) | low
        if value & 0x8000:
            value -= 65536
        return value

    def read_raw(self):
        ax = self.read_i16(self.ACCEL_XOUT_H + 0)
        ay = self.read_i16(self.ACCEL_XOUT_H + 2)
        az = self.read_i16(self.ACCEL_XOUT_H + 4)
        gx = self.read_i16(self.ACCEL_XOUT_H + 8)
        gy = self.read_i16(self.ACCEL_XOUT_H + 10)
        gz = self.read_i16(self.ACCEL_XOUT_H + 12)
        return ax, ay, az, gx, gy, gz

    def calibrate_gyro_z(self):
        self.get_logger().info('Keep robot still: calibrating gyro Z offset...')
        samples = []
        for _ in range(max(1, self.calibration_samples)):
            try:
                *_, gz = self.read_raw()
                samples.append(gz * self.gyro_scale)
                time.sleep(0.005)
            except Exception:
                pass
        if samples:
            self.gyro_z_offset_dps = sum(samples) / len(samples)
            self.get_logger().info(f'Gyro Z offset = {self.gyro_z_offset_dps:.4f} deg/s')

    def timer_callback(self):
        if self.bus is None:
            self.connect()
            return
        now = time.monotonic()
        dt = now - self.last_time
        self.last_time = now
        if dt <= 0.0 or dt > 1.0:
            dt = 1.0 / max(1.0, self.rate)
        try:
            ax_raw, ay_raw, az_raw, gx_raw, gy_raw, gz_raw = self.read_raw()
        except Exception as exc:
            self.get_logger().warn(f'IMU read failed: {exc}')
            self.bus = None
            return

        ax = ax_raw * self.accel_scale
        ay = ay_raw * self.accel_scale
        az = az_raw * self.accel_scale
        gx = math.radians(gx_raw * self.gyro_scale)
        gy = math.radians(gy_raw * self.gyro_scale)
        gz = math.radians(gz_raw * self.gyro_scale - self.gyro_z_offset_dps)
        self.yaw = wrap_angle(self.yaw + gz * dt)

        msg = Imu()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.frame_id
        msg.orientation = yaw_to_quaternion(self.yaw)
        msg.orientation_covariance = [0.05, 0.0, 0.0, 0.0, 0.05, 0.0, 0.0, 0.0, 0.15]
        msg.angular_velocity.x = gx
        msg.angular_velocity.y = gy
        msg.angular_velocity.z = gz
        msg.angular_velocity_covariance = [0.02, 0.0, 0.0, 0.0, 0.02, 0.0, 0.0, 0.0, 0.03]
        msg.linear_acceleration.x = ax
        msg.linear_acceleration.y = ay
        msg.linear_acceleration.z = az
        msg.linear_acceleration_covariance = [0.2, 0.0, 0.0, 0.0, 0.2, 0.0, 0.0, 0.0, 0.2]
        self.imu_pub.publish(msg)

        yaw_msg = Float32()
        yaw_msg.data = float(self.yaw)
        self.yaw_pub.publish(yaw_msg)

    def status_timer_callback(self):
        msg = String()
        msg.data = f'connected={self.bus is not None}, yaw_rad={self.yaw:.3f}, gyro_z_offset_dps={self.gyro_z_offset_dps:.4f}'
        self.status_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = PiImuNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
