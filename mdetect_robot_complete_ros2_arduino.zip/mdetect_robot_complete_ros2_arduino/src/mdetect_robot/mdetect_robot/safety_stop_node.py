import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool, Float32


class SafetyStopNode(Node):
    def __init__(self):
        super().__init__('safety_stop')
        self.declare_parameter('front_stop_distance_m', 0.30)
        self.declare_parameter('front_cone_deg', 30.0)
        self.declare_parameter('latch_stop', False)
        self.front_stop_distance = float(self.get_parameter('front_stop_distance_m').value)
        self.front_cone = math.radians(float(self.get_parameter('front_cone_deg').value))
        self.latch_stop = bool(self.get_parameter('latch_stop').value)
        self.stopped = False
        self.stop_pub = self.create_publisher(Bool, 'emergency_stop', 10)
        self.front_dist_pub = self.create_publisher(Float32, 'front_obstacle_distance', 10)
        self.create_subscription(LaserScan, 'scan', self.scan_callback, 10)

    def scan_callback(self, scan):
        nearest = float('inf')
        angle = scan.angle_min
        for r in scan.ranges:
            if math.isfinite(r) and scan.range_min <= r <= scan.range_max:
                a = math.atan2(math.sin(angle), math.cos(angle))
                if abs(a) <= self.front_cone * 0.5:
                    nearest = min(nearest, r)
            angle += scan.angle_increment
        dmsg = Float32()
        dmsg.data = nearest if math.isfinite(nearest) else -1.0
        self.front_dist_pub.publish(dmsg)
        should_stop = math.isfinite(nearest) and nearest < self.front_stop_distance
        if should_stop:
            self.stopped = True
        elif not self.latch_stop:
            self.stopped = False
        msg = Bool()
        msg.data = bool(self.stopped)
        self.stop_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = SafetyStopNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
