import heapq
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseArray, Pose
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from .utils import quaternion_to_yaw, yaw_to_quaternion, world_to_grid, grid_to_world


class RoutePlannerNode(Node):
    def __init__(self):
        super().__init__('route_planner')
        self.declare_parameter('occupied_cost', 70)
        self.declare_parameter('max_route_points', 10)
        self.declare_parameter('auto_replan', True)
        self.occupied_cost = int(self.get_parameter('occupied_cost').value)
        self.max_route_points = int(self.get_parameter('max_route_points').value)
        self.auto_replan = bool(self.get_parameter('auto_replan').value)
        self.costmap = None
        self.pose = None
        self.goal = None
        self.path_pub = self.create_publisher(Path, 'planned_path', 10)
        self.route_points_pub = self.create_publisher(PoseArray, 'route_points', 10)
        self.create_subscription(OccupancyGrid, 'costmap', self.costmap_callback, 5)
        self.create_subscription(Odometry, 'odom', self.odom_callback, 20)
        self.create_subscription(PoseStamped, 'goal_pose', self.goal_callback, 10)

    def odom_callback(self, odom):
        self.pose = (odom.pose.pose.position.x, odom.pose.pose.position.y, quaternion_to_yaw(odom.pose.pose.orientation))

    def goal_callback(self, goal):
        self.goal = (goal.pose.position.x, goal.pose.position.y)
        self.plan_and_publish('new goal')

    def costmap_callback(self, costmap):
        self.costmap = costmap
        if self.auto_replan and self.goal is not None:
            self.plan_and_publish('costmap update')

    def idx(self, gx, gy):
        return gy * self.costmap.info.width + gx

    def in_bounds(self, gx, gy):
        return 0 <= gx < self.costmap.info.width and 0 <= gy < self.costmap.info.height

    def is_free(self, gx, gy):
        if not self.in_bounds(gx, gy):
            return False
        value = self.costmap.data[self.idx(gx, gy)]
        return value >= 0 and value < self.occupied_cost

    def neighbors(self, gx, gy):
        moves = [(-1,0,1),(1,0,1),(0,-1,1),(0,1,1),(-1,-1,1.414),(1,-1,1.414),(-1,1,1.414),(1,1,1.414)]
        for dx, dy, cost in moves:
            nx, ny = gx + dx, gy + dy
            if self.is_free(nx, ny):
                yield nx, ny, cost

    def astar(self, start, goal):
        sx, sy = start
        gx, gy = goal
        open_set = []
        heapq.heappush(open_set, (0.0, (sx, sy)))
        came = {}
        gscore = {(sx, sy): 0.0}
        closed = set()
        while open_set:
            _, current = heapq.heappop(open_set)
            if current in closed:
                continue
            if current == (gx, gy):
                path = [current]
                while current in came:
                    current = came[current]
                    path.append(current)
                return list(reversed(path))
            closed.add(current)
            for nx, ny, move_cost in self.neighbors(*current):
                ng = gscore[current] + move_cost + max(0, self.costmap.data[self.idx(nx, ny)]) / 100.0
                if (nx, ny) not in gscore or ng < gscore[(nx, ny)]:
                    gscore[(nx, ny)] = ng
                    h = math.hypot(gx - nx, gy - ny)
                    heapq.heappush(open_set, (ng + h, (nx, ny)))
                    came[(nx, ny)] = current
        return []

    def simplify_path(self, pts):
        if len(pts) <= 2:
            return pts
        simplified = [pts[0]]
        last_dir = None
        for i in range(1, len(pts)):
            direction = (pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
            if last_dir is None:
                last_dir = direction
            elif direction != last_dir:
                simplified.append(pts[i - 1])
                last_dir = direction
        simplified.append(pts[-1])
        return simplified

    def limit_route_points(self, pts):
        if len(pts) <= self.max_route_points:
            return pts
        return [pts[round(i * (len(pts) - 1) / (self.max_route_points - 1))] for i in range(self.max_route_points)]

    def plan_and_publish(self, reason):
        if self.costmap is None or self.pose is None or self.goal is None:
            return
        ox = self.costmap.info.origin.position.x
        oy = self.costmap.info.origin.position.y
        res = self.costmap.info.resolution
        start = world_to_grid(self.pose[0], self.pose[1], ox, oy, res)
        goal = world_to_grid(self.goal[0], self.goal[1], ox, oy, res)
        if not self.is_free(*start) or not self.is_free(*goal):
            self.get_logger().warn('Cannot plan: start or goal is inside inflated cost map')
            return
        grid_path = self.astar(start, goal)
        if not grid_path:
            self.get_logger().warn(f'No path found ({reason})')
            return
        world_path = [grid_to_world(gx, gy, ox, oy, res) for gx, gy in grid_path]
        route = self.limit_route_points([grid_to_world(gx, gy, ox, oy, res) for gx, gy in self.simplify_path(grid_path)])
        self.publish_path(world_path)
        self.publish_route_points(route)
        self.get_logger().info(f'Path planned ({reason}): {len(world_path)} path cells, {len(route)} route points')

    def publish_path(self, world_path):
        msg = Path()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.costmap.header.frame_id
        for x, y in world_path:
            pose = PoseStamped()
            pose.header = msg.header
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.orientation.w = 1.0
            msg.poses.append(pose)
        self.path_pub.publish(msg)

    def publish_route_points(self, route):
        msg = PoseArray()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.costmap.header.frame_id
        for i, (x, y) in enumerate(route):
            pose = Pose()
            pose.position.x = x
            pose.position.y = y
            yaw = 0.0
            if i < len(route) - 1:
                yaw = math.atan2(route[i + 1][1] - y, route[i + 1][0] - x)
            pose.orientation = yaw_to_quaternion(yaw)
            msg.poses.append(pose)
        self.route_points_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = RoutePlannerNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
