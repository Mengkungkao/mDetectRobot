import time
import serial

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool, Int32MultiArray, String


class ArduinoMotorBridge(Node):
    def __init__(self):
        super().__init__('arduino_motor_bridge')
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baud', 500000)
        self.declare_parameter('timeout', 0.0)
        self.declare_parameter('command_rate_hz', 20.0)
        self.declare_parameter('cmd_timeout_sec', 0.5)
        self.declare_parameter('max_forward_m_s', 0.35)
        self.declare_parameter('max_right_m_s', 0.35)
        self.declare_parameter('max_yaw_rad_s', 1.0)
        self.declare_parameter('reset_on_connect', False)

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)
        self.timeout = float(self.get_parameter('timeout').value)
        self.command_rate_hz = float(self.get_parameter('command_rate_hz').value)
        self.cmd_timeout_sec = float(self.get_parameter('cmd_timeout_sec').value)
        self.max_forward_m_s = float(self.get_parameter('max_forward_m_s').value)
        self.max_right_m_s = float(self.get_parameter('max_right_m_s').value)
        self.max_yaw_rad_s = float(self.get_parameter('max_yaw_rad_s').value)
        self.reset_on_connect = bool(self.get_parameter('reset_on_connect').value)

        self.serial = None
        self.rx_buffer = bytearray()
        self.last_cmd = Twist()
        self.last_cmd_time = time.monotonic()
        self.emergency_stop = False
        self.last_ticks = None
        self.last_raw_line = ''

        self.ticks_pub = self.create_publisher(Int32MultiArray, 'wheel_ticks', 20)
        self.delta_pub = self.create_publisher(Int32MultiArray, 'wheel_delta_ticks', 20)
        self.status_pub = self.create_publisher(String, 'arduino/status', 10)

        self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 20)
        self.create_subscription(Bool, 'emergency_stop', self.emergency_stop_callback, 10)
        self.create_subscription(Bool, 'reset_arduino', self.reset_arduino_callback, 10)
        self.create_subscription(Bool, 'reset_encoders', self.reset_encoders_callback, 10)

        self.connect()
        self.create_timer(0.005, self.read_timer_callback)
        self.create_timer(1.0 / max(1.0, self.command_rate_hz), self.command_timer_callback)
        self.create_timer(1.0, self.status_timer_callback)

    def connect(self):
        try:
            self.serial = serial.Serial(self.port, self.baud, timeout=self.timeout, write_timeout=0)
            if self.reset_on_connect:
                self.serial.setDTR(False)
                time.sleep(0.1)
                self.serial.setDTR(True)
                time.sleep(2.0)
            else:
                time.sleep(0.2)
            self.get_logger().info(f'Connected to Arduino on {self.port} at {self.baud}')
        except Exception as exc:
            self.serial = None
            self.get_logger().error(f'Failed to open Arduino serial {self.port}: {exc}')

    def safe_write(self, text):
        if self.serial is None:
            return
        try:
            self.serial.write(text.encode('ascii'))
        except Exception as exc:
            self.get_logger().warn(f'Serial write failed: {exc}')
            self.serial = None

    def cmd_vel_callback(self, msg):
        self.last_cmd = msg
        self.last_cmd_time = time.monotonic()

    def emergency_stop_callback(self, msg):
        self.emergency_stop = bool(msg.data)
        if self.emergency_stop:
            self.safe_write('STOP:\n')

    def reset_arduino_callback(self, msg):
        if not msg.data or self.serial is None:
            return
        self.safe_write('STOP:\n')
        try:
            self.get_logger().warn('Resetting Arduino using DTR line')
            self.serial.setDTR(False)
            time.sleep(0.1)
            self.serial.setDTR(True)
            time.sleep(2.0)
            self.serial.reset_input_buffer()
            self.serial.reset_output_buffer()
            self.last_ticks = None
        except Exception as exc:
            self.get_logger().error(f'Arduino reset failed: {exc}')

    def reset_encoders_callback(self, msg):
        if msg.data:
            self.safe_write('RESET_ENC:\n')
            self.last_ticks = None

    def command_timer_callback(self):
        if self.serial is None:
            self.connect()
            return
        now = time.monotonic()
        if self.emergency_stop or (now - self.last_cmd_time) > self.cmd_timeout_sec:
            self.safe_write('CMD,0,0,0\n')
            return

        forward_m_s = max(-self.max_forward_m_s, min(self.max_forward_m_s, self.last_cmd.linear.x))
        right_m_s = max(-self.max_right_m_s, min(self.max_right_m_s, -self.last_cmd.linear.y))
        yaw_rad_s = max(-self.max_yaw_rad_s, min(self.max_yaw_rad_s, self.last_cmd.angular.z))
        self.safe_write(f'CMD,{right_m_s * 1000.0:.1f},{forward_m_s * 1000.0:.1f},{yaw_rad_s * 57.2957795131:.1f}\n')

    def read_timer_callback(self):
        if self.serial is None:
            return
        try:
            data = self.serial.read(4096)
            if not data:
                return
            self.rx_buffer.extend(data)
            while b'\n' in self.rx_buffer:
                line, _, rest = self.rx_buffer.partition(b'\n')
                self.rx_buffer = bytearray(rest)
                self.handle_line(line.decode(errors='ignore').strip())
        except Exception as exc:
            self.get_logger().warn(f'Serial read failed: {exc}')
            self.serial = None

    def handle_line(self, line):
        if not line:
            return
        self.last_raw_line = line
        if line.startswith('ENC,'):
            parts = line.split(',')
            if len(parts) >= 6:
                try:
                    ticks = [int(float(parts[2])), int(float(parts[3])), int(float(parts[4])), int(float(parts[5]))]
                except ValueError:
                    return
                msg = Int32MultiArray()
                msg.data = ticks
                self.ticks_pub.publish(msg)
                if self.last_ticks is not None:
                    dmsg = Int32MultiArray()
                    dmsg.data = [ticks[i] - self.last_ticks[i] for i in range(4)]
                    self.delta_pub.publish(dmsg)
                self.last_ticks = ticks
        elif line.startswith(('OK', 'ERR', 'STOPPED', 'PONG')):
            self.get_logger().info(line)

    def status_timer_callback(self):
        msg = String()
        connected = self.serial is not None and self.serial.is_open
        msg.data = f'connected={connected}, emergency_stop={self.emergency_stop}, last_line={self.last_raw_line}'
        self.status_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ArduinoMotorBridge()
    try:
        rclpy.spin(node)
    finally:
        if node.serial is not None:
            node.safe_write('STOP:\n')
            node.serial.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
