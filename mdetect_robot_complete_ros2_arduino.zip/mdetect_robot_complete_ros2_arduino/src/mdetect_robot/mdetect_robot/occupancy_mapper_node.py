import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid, Odometry
from .utils import quaternion_to_yaw, world_to_grid, bresenham


class OccupancyMapperNode(Node):
    def __init__(self):
        super().__init__('occupancy_mapper')
        self.declare_parameter('resolution_m', 0.05)
        self.declare_parameter('width_m', 12.0)
        self.declare_parameter('height_m', 12.0)
        self.declare_parameter('origin_x_m', -6.0)
        self.declare_parameter('origin_y_m', -6.0)
        self.declare_parameter('robot_radius_m', 0.20)
        self.declare_parameter('extra_clearance_m', 0.05)
        self.declare_parameter('occupied_threshold', 65)
        self.resolution = float(self.get_parameter('resolution_m').value)
        self.width = int(float(self.get_parameter('width_m').value) / self.resolution)
        self.height = int(float(self.get_parameter('height_m').value) / self.resolution)
        self.origin_x = float(self.get_parameter('origin_x_m').value)
        self.origin_y = float(self.get_parameter('origin_y_m').value)
        self.robot_radius = float(self.get_parameter('robot_radius_m').value)
        self.extra_clearance = float(self.get_parameter('extra_clearance_m').value)
        self.occupied_threshold = int(self.get_parameter('occupied_threshold').value)
        self.grid = [50] * (self.width * self.height)
        self.pose = None
        self.map_pub = self.create_publisher(OccupancyGrid, 'map', 2)
        self.costmap_pub = self.create_publisher(OccupancyGrid, 'costmap', 2)
        self.create_subscription(Odometry, 'odom', self.odom_callback, 20)
        self.create_subscription(LaserScan, 'scan', self.scan_callback, 10)
        self.create_timer(0.5, self.publish_maps)

    def index(self, gx, gy):
        return gy * self.width + gx

    def in_bounds(self, gx, gy):
        return 0 <= gx < self.width and 0 <= gy < self.height

    def odom_callback(self, odom):
        self.pose = (odom.pose.pose.position.x, odom.pose.pose.position.y, quaternion_to_yaw(odom.pose.pose.orientation))

    def scan_callback(self, scan):
        if self.pose is None:
            return
        rx, ry, yaw = self.pose
        rgx, rgy = world_to_grid(rx, ry, self.origin_x, self.origin_y, self.resolution)
        if not self.in_bounds(rgx, rgy):
            return
        angle = scan.angle_min
        for r in scan.ranges:
            if math.isfinite(r) and scan.range_min <= r <= scan.range_max:
                wx = rx + math.cos(yaw + angle) * r
                wy = ry + math.sin(yaw + angle) * r
                gx, gy = world_to_grid(wx, wy, self.origin_x, self.origin_y, self.resolution)
                if self.in_bounds(gx, gy):
                    for cx, cy in bresenham(rgx, rgy, gx, gy)[:-1]:
                        self.grid[self.index(cx, cy)] = max(0, self.grid[self.index(cx, cy)] - 2)
                    self.grid[self.index(gx, gy)] = min(100, self.grid[self.index(gx, gy)] + 15)
            angle += scan.angle_increment

    def make_msg(self, data):
        msg = OccupancyGrid()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'odom'
        msg.info.resolution = self.resolution
        msg.info.width = self.width
        msg.info.height = self.height
        msg.info.origin.position.x = self.origin_x
        msg.info.origin.position.y = self.origin_y
        msg.info.origin.orientation.w = 1.0
        msg.data = [int(v) for v in data]
        return msg

    def build_costmap(self):
        cost = [0 if v < self.occupied_threshold else 100 for v in self.grid]
        inflate = int(math.ceil((self.robot_radius + self.extra_clearance) / self.resolution))
        occupied = [(i % self.width, i // self.width) for i, v in enumerate(cost) if v >= 100]
        for gx, gy in occupied:
            for dy in range(-inflate, inflate + 1):
                for dx in range(-inflate, inflate + 1):
                    nx, ny = gx + dx, gy + dy
                    if self.in_bounds(nx, ny) and math.hypot(dx, dy) <= inflate:
                        cost[self.index(nx, ny)] = 100
        return cost

    def publish_maps(self):
        self.map_pub.publish(self.make_msg(self.grid))
        self.costmap_pub.publish(self.make_msg(self.build_costmap()))


def main(args=None):
    rclpy.init(args=args)
    node = OccupancyMapperNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
