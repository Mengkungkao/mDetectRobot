import math
import time
import serial

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String


class CoinD6LidarNode(Node):
    def __init__(self):
        super().__init__('coin_d6_lidar')
        self.declare_parameter('port', '/dev/ttyUSB1')
        self.declare_parameter('baud', 230400)
        self.declare_parameter('timeout', 0.0)
        self.declare_parameter('frame_id', 'laser')
        self.declare_parameter('scan_rate_hz', 10.0)
        self.declare_parameter('angle_offset_deg', 0.0)
        self.declare_parameter('reverse_angle', False)
        self.declare_parameter('range_min_m', 0.05)
        self.declare_parameter('range_max_m', 8.0)
        self.declare_parameter('bins', 360)

        self.port = self.get_parameter('port').value
        self.baud = int(self.get_parameter('baud').value)
        self.timeout = float(self.get_parameter('timeout').value)
        self.frame_id = self.get_parameter('frame_id').value
        self.scan_rate_hz = float(self.get_parameter('scan_rate_hz').value)
        self.angle_offset = math.radians(float(self.get_parameter('angle_offset_deg').value))
        self.reverse_angle = bool(self.get_parameter('reverse_angle').value)
        self.range_min = float(self.get_parameter('range_min_m').value)
        self.range_max = float(self.get_parameter('range_max_m').value)
        self.bins = int(self.get_parameter('bins').value)

        self.serial = None
        self.buffer = bytearray()
        self.ranges = [float('inf')] * self.bins
        self.scan_pub = self.create_publisher(LaserScan, 'scan', 10)
        self.status_pub = self.create_publisher(String, 'lidar/status', 10)
        self.connect()
        self.create_timer(0.002, self.read_timer_callback)
        self.create_timer(1.0 / max(1.0, self.scan_rate_hz), self.publish_scan)
        self.create_timer(1.0, self.status_timer_callback)

    def connect(self):
        try:
            self.serial = serial.Serial(self.port, self.baud, timeout=self.timeout)
            time.sleep(0.2)
            self.serial.write(bytes([0xAA, 0x55, 0xF0, 0x0F]))
            self.get_logger().info(f'COIN-D6 LiDAR connected on {self.port}')
        except Exception as exc:
            self.serial = None
            self.get_logger().error(f'Failed to open COIN-D6 LiDAR serial {self.port}: {exc}')

    def stop_lidar(self):
        if self.serial is not None:
            try:
                self.serial.write(bytes([0xAA, 0x55, 0xF5, 0x0A]))
                self.serial.close()
            except Exception:
                pass

    def read_timer_callback(self):
        if self.serial is None:
            self.connect()
            return
        try:
            data = self.serial.read(4096)
            if data:
                self.buffer.extend(data)
                self.parse_buffer()
        except Exception as exc:
            self.get_logger().warn(f'LiDAR read failed: {exc}')
            self.serial = None

    def parse_buffer(self):
        while len(self.buffer) >= 12:
            if self.buffer[0] != 0xAA or self.buffer[1] != 0x55:
                del self.buffer[0]
                continue
            count = self.buffer[3] & 0x1F
            if count <= 0 or count > 16:
                count = 12
            packet_len = 10 + count * 3
            if len(self.buffer) < packet_len:
                return
            packet = bytes(self.buffer[:packet_len])
            del self.buffer[:packet_len]
            try:
                start_raw = packet[4] | (packet[5] << 8)
                end_raw = packet[6] | (packet[7] << 8)
                start_deg = (start_raw >> 1) / 64.0
                end_deg = (end_raw >> 1) / 64.0
                if end_deg < start_deg:
                    end_deg += 360.0
                step = 0.0 if count <= 1 else (end_deg - start_deg) / (count - 1)
                idx = 8
                for i in range(count):
                    if idx + 1 >= len(packet):
                        break
                    dist_mm = packet[idx] | (packet[idx + 1] << 8)
                    idx += 3
                    if dist_mm <= 0:
                        continue
                    angle = math.radians((start_deg + step * i) % 360.0)
                    if self.reverse_angle:
                        angle = -angle
                    angle = (angle + self.angle_offset + 2.0 * math.pi) % (2.0 * math.pi)
                    r = dist_mm / 1000.0
                    if self.range_min <= r <= self.range_max:
                        bin_id = int(angle / (2.0 * math.pi) * self.bins) % self.bins
                        self.ranges[bin_id] = min(self.ranges[bin_id], r)
            except Exception:
                continue

    def publish_scan(self):
        scan = LaserScan()
        scan.header.stamp = self.get_clock().now().to_msg()
        scan.header.frame_id = self.frame_id
        scan.angle_min = 0.0
        scan.angle_max = 2.0 * math.pi
        scan.angle_increment = 2.0 * math.pi / self.bins
        scan.scan_time = 1.0 / max(1.0, self.scan_rate_hz)
        scan.range_min = self.range_min
        scan.range_max = self.range_max
        scan.ranges = self.ranges
        self.scan_pub.publish(scan)
        self.ranges = [float('inf')] * self.bins

    def status_timer_callback(self):
        msg = String()
        msg.data = f'connected={self.serial is not None and self.serial.is_open}, port={self.port}'
        self.status_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = CoinD6LidarNode()
    try:
        rclpy.spin(node)
    finally:
        node.stop_lidar()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
