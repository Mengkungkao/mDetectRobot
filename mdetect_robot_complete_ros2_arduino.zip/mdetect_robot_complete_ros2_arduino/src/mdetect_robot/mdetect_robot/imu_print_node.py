import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class ImuPrintNode(Node):
    def __init__(self):
        super().__init__('imu_print')
        self.create_subscription(Float32, 'imu/yaw', self.cb, 10)

    def cb(self, msg):
        self.get_logger().info(f'Yaw: {math.degrees(msg.data):.2f} deg')


def main(args=None):
    rclpy.init(args=args)
    node = ImuPrintNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
