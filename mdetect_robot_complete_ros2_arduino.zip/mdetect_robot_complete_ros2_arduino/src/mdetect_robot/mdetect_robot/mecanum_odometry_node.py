import math
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray, Float32
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster

from .utils import yaw_to_quaternion, wrap_angle


class MecanumOdometryNode(Node):
    def __init__(self):
        super().__init__('mecanum_odometry')
        self.declare_parameter('ticks_per_rev', 4320.0)
        self.declare_parameter('wheel_diameter_m', 0.0805)
        self.declare_parameter('half_length_m', 0.150)
        self.declare_parameter('half_width_m', 0.100)
        self.declare_parameter('wheel_sign_fl', 1.0)
        self.declare_parameter('wheel_sign_fr', 1.0)
        self.declare_parameter('wheel_sign_rl', 1.0)
        self.declare_parameter('wheel_sign_rr', 1.0)
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('publish_tf', True)

        self.ticks_per_rev = float(self.get_parameter('ticks_per_rev').value)
        self.wheel_circ = math.pi * float(self.get_parameter('wheel_diameter_m').value)
        self.k = float(self.get_parameter('half_length_m').value) + float(self.get_parameter('half_width_m').value)
        self.signs = [
            float(self.get_parameter('wheel_sign_fl').value),
            float(self.get_parameter('wheel_sign_fr').value),
            float(self.get_parameter('wheel_sign_rl').value),
            float(self.get_parameter('wheel_sign_rr').value),
        ]
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.publish_tf = bool(self.get_parameter('publish_tf').value)

        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.last_ticks = None
        self.last_time = time.monotonic()
        self.last_vx = 0.0
        self.last_vy = 0.0
        self.last_wz = 0.0

        self.odom_pub = self.create_publisher(Odometry, 'odom', 20)
        self.tf_broadcaster = TransformBroadcaster(self)
        self.create_subscription(Int32MultiArray, 'wheel_ticks', self.ticks_callback, 50)
        self.create_subscription(Float32, 'imu/yaw', self.yaw_callback, 50)
        self.create_timer(0.05, self.publish_timer)

    def yaw_callback(self, msg):
        self.yaw = wrap_angle(float(msg.data))

    def ticks_callback(self, msg):
        if len(msg.data) < 4:
            return
        ticks = [int(msg.data[0]), int(msg.data[1]), int(msg.data[2]), int(msg.data[3])]
        now = time.monotonic()
        dt = now - self.last_time
        self.last_time = now
        if self.last_ticks is None or dt <= 0.0 or dt > 1.0:
            self.last_ticks = ticks
            return
        delta_ticks = [(ticks[i] - self.last_ticks[i]) * self.signs[i] for i in range(4)]
        self.last_ticks = ticks
        dist = [d / self.ticks_per_rev * self.wheel_circ for d in delta_ticks]
        fl, fr, rl, rr = dist

        dx_body = (fl + fr + rl + rr) / 4.0
        dy_body = (-fl + fr + rl - rr) / 4.0
        dyaw_wheel = (-fl + fr - rl + rr) / (4.0 * max(1e-6, self.k))

        c = math.cos(self.yaw)
        s = math.sin(self.yaw)
        self.x += c * dx_body - s * dy_body
        self.y += s * dx_body + c * dy_body
        self.last_vx = dx_body / dt
        self.last_vy = dy_body / dt
        self.last_wz = dyaw_wheel / dt

    def publish_timer(self):
        stamp = self.get_clock().now().to_msg()
        q = yaw_to_quaternion(self.yaw)
        odom = Odometry()
        odom.header.stamp = stamp
        odom.header.frame_id = self.odom_frame
        odom.child_frame_id = self.base_frame
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation = q
        odom.twist.twist.linear.x = self.last_vx
        odom.twist.twist.linear.y = self.last_vy
        odom.twist.twist.angular.z = self.last_wz
        odom.pose.covariance[0] = 0.03
        odom.pose.covariance[7] = 0.03
        odom.pose.covariance[35] = 0.15
        self.odom_pub.publish(odom)
        if self.publish_tf:
            tf = TransformStamped()
            tf.header.stamp = stamp
            tf.header.frame_id = self.odom_frame
            tf.child_frame_id = self.base_frame
            tf.transform.translation.x = self.x
            tf.transform.translation.y = self.y
            tf.transform.rotation = q
            self.tf_broadcaster.sendTransform(tf)


def main(args=None):
    rclpy.init(args=args)
    node = MecanumOdometryNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
