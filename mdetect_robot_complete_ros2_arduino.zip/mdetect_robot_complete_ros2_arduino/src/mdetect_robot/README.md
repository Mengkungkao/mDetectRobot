# MDetect Robot - ROS2 Humble, Raspberry Pi IMU Architecture

This package uses the cleaner architecture:

- Arduino = encoder reader + motor PID controller only.
- Raspberry Pi = MPU9250/6500/9255 IMU + COIN-D6 LiDAR + odometry + mapping + planning.

## Arduino serial

Output:

```text
ENC,time_ms,fl_ticks,fr_ticks,rl_ticks,rr_ticks
```

Commands:

```text
CMD,right_mm_s,forward_mm_s,yaw_deg_s
STOP:
RESET_ENC:
PING:
```

## Coordinate convention

ROS:
- `odom.x` = forward.
- `odom.y` = left.
- yaw positive = counter-clockwise.

Arduino command:
- `right_mm_s` positive = right.
- `forward_mm_s` positive = forward.
- `yaw_deg_s` positive = counter-clockwise.

The Arduino motor bridge converts ROS `/cmd_vel` into the Arduino command format.
