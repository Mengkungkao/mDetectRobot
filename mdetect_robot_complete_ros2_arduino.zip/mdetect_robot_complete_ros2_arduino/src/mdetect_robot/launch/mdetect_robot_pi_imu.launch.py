import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('mdetect_robot')
    default_params = os.path.join(pkg_share, 'config', 'robot_params.yaml')
    params = LaunchConfiguration('params')
    return LaunchDescription([
        DeclareLaunchArgument('params', default_value=default_params),
        Node(package='mdetect_robot', executable='arduino_motor_bridge', name='arduino_motor_bridge', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='pi_imu', name='pi_imu', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='mecanum_odometry', name='mecanum_odometry', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='coin_d6_lidar', name='coin_d6_lidar', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='safety_stop', name='safety_stop', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='occupancy_mapper', name='occupancy_mapper', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='route_planner', name='route_planner', output='screen', parameters=[params]),
        Node(package='mdetect_robot', executable='pure_pursuit', name='pure_pursuit', output='screen', parameters=[params]),
    ])
