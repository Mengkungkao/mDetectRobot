#!/usr/bin/env python3
"""ROS 2 <-> Arduino high-speed wheel controller bridge.

ROS input:
  /cmd_vel                 geometry_msgs/Twist

ROS outputs:
  /odom                    nav_msgs/Odometry
  /imu/data                sensor_msgs/Imu
  /joint_states            sensor_msgs/JointState
  /arduino/connected       std_msgs/Bool
  /arduino/estop_latched   std_msgs/Bool
  TF odom -> base_footprint

Serial protocol to Uno:
  V,seq,m1_mm_s,m2_mm_s,m3_mm_s,m4_mm_s\n
  B,seq\n                     brake
  E,seq\n                     emergency latch
  C,seq\n                     clear emergency latch

Serial telemetry from Uno:
  T,ms,e1,e2,e3,e4,s1,s2,s3,s4,yaw_deg,estop,watchdog\n
Encoder totals are direction-corrected counts. Motor side mapping follows the
existing robot: motors 1 and 4 are left; motors 2 and 3 are right.
"""

import math
import threading
from typing import Optional

import rclpy
from geometry_msgs.msg import Quaternion, TransformStamped, Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import Imu, JointState
from std_msgs.msg import Bool
from std_srvs.srv import Trigger
from tf2_ros import TransformBroadcaster

try:
    import serial
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("Install pyserial: sudo apt install python3-serial") from exc


def yaw_to_quaternion(yaw: float) -> Quaternion:
    q = Quaternion()
    q.z = math.sin(yaw * 0.5)
    q.w = math.cos(yaw * 0.5)
    return q


def normalize_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


class SerialBridge(Node):
    def __init__(self) -> None:
        super().__init__('serial_bridge')

        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baud', 500000)
        self.declare_parameter('track_width_m', 0.210)
        self.declare_parameter('cmd_vel_topic', '/cmd_vel_safe')
        self.declare_parameter('wheel_diameter_m', 0.0805)
        self.declare_parameter('counts_per_rev', 4320.0)
        self.declare_parameter('command_rate_hz', 50.0)
        self.declare_parameter('cmd_timeout_s', 0.25)
        self.declare_parameter('base_frame', 'base_footprint')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('publish_tf', True)
        self.declare_parameter('imu_yaw_sign', -1.0)
        self.declare_parameter('max_wheel_speed_mm_s', 250.0)

        self.port = str(self.get_parameter('port').value)
        self.baud = int(self.get_parameter('baud').value)
        self.track_width = float(self.get_parameter('track_width_m').value)
        self.cmd_vel_topic = str(self.get_parameter('cmd_vel_topic').value)
        self.wheel_diameter = float(self.get_parameter('wheel_diameter_m').value)
        self.counts_per_rev = float(self.get_parameter('counts_per_rev').value)
        self.command_rate = float(self.get_parameter('command_rate_hz').value)
        self.cmd_timeout = float(self.get_parameter('cmd_timeout_s').value)
        self.base_frame = str(self.get_parameter('base_frame').value)
        self.odom_frame = str(self.get_parameter('odom_frame').value)
        self.publish_tf = bool(self.get_parameter('publish_tf').value)
        self.imu_yaw_sign = float(self.get_parameter('imu_yaw_sign').value)
        self.max_wheel_speed = float(self.get_parameter('max_wheel_speed_mm_s').value)

        self.mm_per_count = math.pi * self.wheel_diameter * 1000.0 / self.counts_per_rev
        self.serial_lock = threading.Lock()
        self.ser: Optional[serial.Serial] = None
        self.rx_buffer = bytearray()
        self.seq = 0

        self.last_cmd = Twist()
        self.last_cmd_time = self.get_clock().now()
        self.last_telemetry_time = self.get_clock().now()
        self.last_encoder_counts: Optional[list[int]] = None
        self.last_yaw: Optional[float] = None
        self.last_odom_stamp = self.get_clock().now()
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.connected = False
        self.estop_latched = False

        self.odom_pub = self.create_publisher(Odometry, '/odom', 20)
        self.imu_pub = self.create_publisher(Imu, '/imu/data', 20)
        self.joint_pub = self.create_publisher(JointState, '/joint_states', 20)
        self.connected_pub = self.create_publisher(Bool, '/arduino/connected', 10)
        self.estop_pub = self.create_publisher(Bool, '/arduino/estop_latched', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        self.create_subscription(Twist, self.cmd_vel_topic, self.cmd_vel_callback, 20)
        self.create_service(Trigger, '/arduino/emergency_stop', self.emergency_stop_callback)
        self.create_service(Trigger, '/arduino/clear_emergency_stop', self.clear_estop_callback)
        self.create_service(Trigger, '/arduino/brake', self.brake_callback)
        self.create_service(Trigger, '/arduino/reset_odometry', self.reset_odom_callback)

        self.open_serial()
        period = 1.0 / max(self.command_rate, 1.0)
        self.create_timer(period, self.control_timer)
        self.create_timer(1.0, self.status_timer)

    def open_serial(self) -> None:
        try:
            self.ser = serial.Serial(
                self.port,
                self.baud,
                timeout=0.0,
                write_timeout=0.02,
                exclusive=True,
            )
            self.connected = True
            self.get_logger().info(f'Opened Arduino {self.port} at {self.baud} baud')
        except (serial.SerialException, OSError) as exc:
            self.ser = None
            self.connected = False
            self.get_logger().error(f'Cannot open Arduino serial port: {exc}')

    def cmd_vel_callback(self, msg: Twist) -> None:
        self.last_cmd = msg
        self.last_cmd_time = self.get_clock().now()

    def send_line(self, line: str) -> bool:
        if self.ser is None or not self.ser.is_open:
            return False
        try:
            with self.serial_lock:
                self.ser.write(line.encode('ascii'))
            return True
        except (serial.SerialException, serial.SerialTimeoutException, OSError) as exc:
            self.get_logger().error(f'Serial write failed: {exc}')
            self.connected = False
            return False

    def next_seq(self) -> int:
        self.seq = (self.seq + 1) & 0xFFFF
        return self.seq

    def send_simple_command(self, code: str) -> bool:
        return self.send_line(f'{code},{self.next_seq()}\n')

    def emergency_stop_callback(self, _request, response):
        response.success = self.send_simple_command('E')
        response.message = 'Emergency-stop latch command sent' if response.success else 'Serial unavailable'
        return response

    def clear_estop_callback(self, _request, response):
        response.success = self.send_simple_command('C')
        response.message = 'Clear emergency-stop command sent' if response.success else 'Serial unavailable'
        return response

    def brake_callback(self, _request, response):
        response.success = self.send_simple_command('B')
        response.message = 'Brake command sent' if response.success else 'Serial unavailable'
        return response

    def reset_odom_callback(self, _request, response):
        self.x = self.y = self.yaw = 0.0
        self.last_encoder_counts = None
        self.last_yaw = None
        response.success = self.send_simple_command('Z')
        response.message = 'ROS odometry reset; Arduino encoder/yaw zero requested'
        return response

    def command_is_stale(self) -> bool:
        age = (self.get_clock().now() - self.last_cmd_time).nanoseconds * 1e-9
        return age > self.cmd_timeout

    def send_wheel_command(self) -> None:
        if self.command_is_stale() or self.estop_latched:
            vx = 0.0
            wz = 0.0
        else:
            vx = float(self.last_cmd.linear.x)
            wz = float(self.last_cmd.angular.z)

        left_mm_s = (vx - wz * self.track_width * 0.5) * 1000.0
        right_mm_s = (vx + wz * self.track_width * 0.5) * 1000.0
        left_mm_s = max(-self.max_wheel_speed, min(self.max_wheel_speed, left_mm_s))
        right_mm_s = max(-self.max_wheel_speed, min(self.max_wheel_speed, right_mm_s))

        # Existing robot side mapping: M1/M4 left and M2/M3 right.
        values = [left_mm_s, right_mm_s, right_mm_s, left_mm_s]
        seq = self.next_seq()
        payload = ','.join(str(int(round(v))) for v in values)
        self.send_line(f'V,{seq},{payload}\n')

    def read_serial(self) -> None:
        if self.ser is None or not self.ser.is_open:
            return
        try:
            waiting = self.ser.in_waiting
            if waiting:
                self.rx_buffer.extend(self.ser.read(min(waiting, 4096)))
        except (serial.SerialException, OSError) as exc:
            self.get_logger().error(f'Serial read failed: {exc}')
            self.connected = False
            return

        while b'\n' in self.rx_buffer:
            raw, _, remaining = self.rx_buffer.partition(b'\n')
            self.rx_buffer = bytearray(remaining)
            line = raw.decode('ascii', errors='ignore').strip()
            if line.startswith('T,'):
                self.parse_telemetry(line)
            elif line.startswith('ERR,'):
                self.get_logger().warning(line)

    def parse_telemetry(self, line: str) -> None:
        fields = line.split(',')
        if len(fields) != 13:
            return
        try:
            _arduino_ms = int(fields[1])
            counts = [int(fields[i]) for i in range(2, 6)]
            speeds = [float(fields[i]) for i in range(6, 10)]
            yaw_deg = float(fields[10]) * self.imu_yaw_sign
            estop = bool(int(fields[11]))
            _watchdog = bool(int(fields[12]))
        except ValueError:
            return

        self.connected = True
        self.estop_latched = estop
        self.last_telemetry_time = self.get_clock().now()
        self.update_odometry(counts, speeds, math.radians(yaw_deg))

    def update_odometry(self, counts: list[int], speeds_mm_s: list[float], imu_yaw: float) -> None:
        now = self.get_clock().now()
        dt = max((now - self.last_odom_stamp).nanoseconds * 1e-9, 1e-4)
        self.last_odom_stamp = now

        if self.last_encoder_counts is None:
            self.last_encoder_counts = counts
            self.last_yaw = imu_yaw
            self.yaw = imu_yaw
            return

        delta = [counts[i] - self.last_encoder_counts[i] for i in range(4)]
        self.last_encoder_counts = counts
        left_mm = 0.5 * (delta[0] + delta[3]) * self.mm_per_count
        right_mm = 0.5 * (delta[1] + delta[2]) * self.mm_per_count
        ds = 0.5 * (left_mm + right_mm) / 1000.0

        previous_yaw = self.yaw
        self.yaw = normalize_angle(imu_yaw)
        midpoint_yaw = normalize_angle(previous_yaw + 0.5 * normalize_angle(self.yaw - previous_yaw))
        self.x += ds * math.cos(midpoint_yaw)
        self.y += ds * math.sin(midpoint_yaw)

        left_speed = 0.5 * (speeds_mm_s[0] + speeds_mm_s[3]) / 1000.0
        right_speed = 0.5 * (speeds_mm_s[1] + speeds_mm_s[2]) / 1000.0
        linear_speed = 0.5 * (left_speed + right_speed)
        angular_speed = normalize_angle(self.yaw - previous_yaw) / dt

        stamp = now.to_msg()
        q = yaw_to_quaternion(self.yaw)

        odom = Odometry()
        odom.header.stamp = stamp
        odom.header.frame_id = self.odom_frame
        odom.child_frame_id = self.base_frame
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation = q
        odom.twist.twist.linear.x = linear_speed
        odom.twist.twist.angular.z = angular_speed
        odom.pose.covariance[0] = 0.02
        odom.pose.covariance[7] = 0.02
        odom.pose.covariance[35] = 0.03
        odom.twist.covariance[0] = 0.05
        odom.twist.covariance[35] = 0.08
        self.odom_pub.publish(odom)

        imu = Imu()
        imu.header.stamp = stamp
        imu.header.frame_id = 'imu_link'
        imu.orientation = q
        imu.angular_velocity.z = angular_speed
        # MPU6050 yaw is provided, but roll and pitch are not fused in this bridge.
        imu.orientation_covariance[0] = 999.0
        imu.orientation_covariance[4] = 999.0
        imu.orientation_covariance[8] = 0.03
        imu.angular_velocity_covariance[0] = 999.0
        imu.angular_velocity_covariance[4] = 999.0
        imu.angular_velocity_covariance[8] = 0.08
        imu.linear_acceleration_covariance[0] = -1.0
        self.imu_pub.publish(imu)

        joint = JointState()
        joint.header.stamp = stamp
        joint.name = ['front_left_wheel_joint', 'front_right_wheel_joint',
                      'rear_right_wheel_joint', 'rear_left_wheel_joint']
        circumference = math.pi * self.wheel_diameter
        joint.position = [c * self.mm_per_count / 1000.0 / (self.wheel_diameter * 0.5) for c in counts]
        joint.velocity = [s / 1000.0 / (self.wheel_diameter * 0.5) for s in speeds_mm_s]
        self.joint_pub.publish(joint)

        if self.publish_tf:
            tf = TransformStamped()
            tf.header.stamp = stamp
            tf.header.frame_id = self.odom_frame
            tf.child_frame_id = self.base_frame
            tf.transform.translation.x = self.x
            tf.transform.translation.y = self.y
            tf.transform.rotation = q
            self.tf_broadcaster.sendTransform(tf)

    def control_timer(self) -> None:
        if self.ser is None or not self.ser.is_open:
            self.open_serial()
            return
        self.read_serial()
        self.send_wheel_command()

    def status_timer(self) -> None:
        telemetry_age = (self.get_clock().now() - self.last_telemetry_time).nanoseconds * 1e-9
        if telemetry_age > 1.0:
            self.connected = False
        self.connected_pub.publish(Bool(data=self.connected))
        self.estop_pub.publish(Bool(data=self.estop_latched))

    def destroy_node(self):
        try:
            self.send_simple_command('B')
            if self.ser is not None:
                self.ser.close()
        finally:
            super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SerialBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
