#!/usr/bin/env python3
"""Send predefined user-coordinate waypoints to Nav2 one at a time.

Input format:
  (x_mm,y_mm,heading_deg,wait_s) (x_mm,y_mm,heading_deg,wait_s)

User coordinate convention preserved from the original robot:
  +X = robot/right side of the map
  +Y = forward/up on the map
  heading 0 deg = +Y
  positive heading = clockwise, toward +X

ROS convention used by Nav2:
  +X = forward/east
  +Y = left/north
  positive yaw = counter-clockwise

Conversion:
  ros_x_m = user_y_mm / 1000
  ros_y_m = -user_x_mm / 1000
  ros_yaw = -heading_deg
"""

import argparse
import math
import re
import sys
import time
from dataclasses import dataclass

import rclpy
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseArray, PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node


WAYPOINT_RE = re.compile(
    r'\(\s*([-+]?\d+(?:\.\d+)?)\s*,\s*'
    r'([-+]?\d+(?:\.\d+)?)\s*,\s*'
    r'([-+]?\d+(?:\.\d+)?)\s*,\s*'
    r'([-+]?\d+(?:\.\d+)?)\s*\)'
)


@dataclass
class Waypoint:
    x_mm: float
    y_mm: float
    heading_deg: float
    wait_s: float


def parse_waypoints(text: str) -> list[Waypoint]:
    points = [Waypoint(*(float(v) for v in match.groups())) for match in WAYPOINT_RE.finditer(text)]
    if not points:
        raise ValueError('No valid waypoints found. Use (x,y,heading,wait).')

    # Reject stray non-space text instead of silently accepting a partly malformed command.
    remaining = WAYPOINT_RE.sub('', text).replace(':', '').strip()
    if remaining:
        raise ValueError(f'Unexpected text outside waypoint tuples: {remaining!r}')
    for point in points:
        if point.wait_s < 0.0:
            raise ValueError('Waiting time cannot be negative.')
    return points


def yaw_quaternion(yaw: float):
    z = math.sin(yaw * 0.5)
    w = math.cos(yaw * 0.5)
    return z, w


class WaypointRunner(Node):
    def __init__(self, points: list[Waypoint], map_frame: str = 'map') -> None:
        super().__init__('waypoint_runner')
        self.points = points
        self.map_frame = map_frame
        self.client = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.waypoint_pub = self.create_publisher(PoseArray, '/mission_waypoints', 10)

    def make_goal(self, point: Waypoint) -> NavigateToPose.Goal:
        goal = NavigateToPose.Goal()
        pose = PoseStamped()
        pose.header.frame_id = self.map_frame
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = point.y_mm / 1000.0
        pose.pose.position.y = -point.x_mm / 1000.0
        yaw = math.radians(-point.heading_deg)
        pose.pose.orientation.z, pose.pose.orientation.w = yaw_quaternion(yaw)
        goal.pose = pose
        return goal

    def publish_waypoints(self) -> None:
        pose_array = PoseArray()
        pose_array.header.frame_id = self.map_frame
        pose_array.header.stamp = self.get_clock().now().to_msg()
        pose_array.poses = [self.make_goal(point).pose.pose for point in self.points]
        self.waypoint_pub.publish(pose_array)

    def run(self) -> int:
        self.get_logger().info('Waiting for Nav2 /navigate_to_pose action server...')
        if not self.client.wait_for_server(timeout_sec=20.0):
            self.get_logger().error('Nav2 action server is not available.')
            return 2

        self.publish_waypoints()
        total = len(self.points)
        for index, point in enumerate(self.points, start=1):
            goal = self.make_goal(point)
            self.get_logger().info(
                f'Waypoint {index}/{total}: user=({point.x_mm:.0f},{point.y_mm:.0f},'
                f'{point.heading_deg:.1f},{point.wait_s:.1f}) -> '
                f'ROS=({goal.pose.pose.position.x:.3f},{goal.pose.pose.position.y:.3f},'
                f'{math.radians(-point.heading_deg):.3f} rad)'
            )

            send_future = self.client.send_goal_async(goal)
            rclpy.spin_until_future_complete(self, send_future)
            goal_handle = send_future.result()
            if goal_handle is None or not goal_handle.accepted:
                self.get_logger().error(f'Waypoint {index} was rejected by Nav2.')
                return 3

            result_future = goal_handle.get_result_async()
            rclpy.spin_until_future_complete(self, result_future)
            wrapped_result = result_future.result()
            if wrapped_result is None or wrapped_result.status != GoalStatus.STATUS_SUCCEEDED:
                status = None if wrapped_result is None else wrapped_result.status
                self.get_logger().error(f'Waypoint {index} failed with action status {status}.')
                return 4

            self.get_logger().info(f'Waypoint {index} reached.')
            if point.wait_s > 0.0:
                self.get_logger().info(f'Waiting {point.wait_s:.1f} seconds.')
                end_time = time.monotonic() + point.wait_s
                while rclpy.ok() and time.monotonic() < end_time:
                    rclpy.spin_once(self, timeout_sec=min(0.1, end_time - time.monotonic()))

        self.get_logger().info('All waypoints completed.')
        return 0


def main(args=None) -> None:
    parser = argparse.ArgumentParser(description='Run mDetect predefined Nav2 waypoints.')
    parser.add_argument(
        '--points',
        help='Example: "(0,2000,0,0) (1000,2000,0,0)". Prompts when omitted.',
    )
    parser.add_argument('--frame', default='map', help='Goal frame, normally map.')
    parsed, ros_args = parser.parse_known_args(args=args)

    text = parsed.points
    if not text:
        text = input('Enter waypoints (x_mm,y_mm,heading_deg,wait_s): ').strip()

    try:
        points = parse_waypoints(text)
    except ValueError as exc:
        print(f'Invalid waypoint input: {exc}', file=sys.stderr)
        raise SystemExit(1)

    rclpy.init(args=ros_args)
    node = WaypointRunner(points, parsed.frame)
    try:
        code = node.run()
    except KeyboardInterrupt:
        code = 130
    finally:
        node.destroy_node()
        rclpy.shutdown()
    raise SystemExit(code)


if __name__ == '__main__':
    main()
