See the top-level README.md in the distributed starter bundle.
