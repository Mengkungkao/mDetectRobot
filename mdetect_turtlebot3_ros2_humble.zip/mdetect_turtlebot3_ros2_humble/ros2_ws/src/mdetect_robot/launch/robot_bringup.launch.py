import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    pkg = get_package_share_directory('mdetect_robot')
    xacro_file = os.path.join(pkg, 'urdf', 'mdetect_robot.urdf.xacro')
    collision_params = os.path.join(pkg, 'config', 'collision_monitor.yaml')

    arduino_port = LaunchConfiguration('arduino_port')
    arduino_baud = LaunchConfiguration('arduino_baud')
    use_sim_time = LaunchConfiguration('use_sim_time')

    robot_description = ParameterValue(
        Command(['xacro ', xacro_file]), value_type=str
    )

    return LaunchDescription([
        DeclareLaunchArgument('arduino_port', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('arduino_baud', default_value='500000'),
        DeclareLaunchArgument('use_sim_time', default_value='false'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{
                'use_sim_time': use_sim_time,
                'robot_description': robot_description,
            }],
        ),

        Node(
            package='mdetect_robot',
            executable='serial_bridge',
            name='serial_bridge',
            output='screen',
            parameters=[{
                'port': arduino_port,
                'baud': arduino_baud,
                'cmd_vel_topic': '/cmd_vel_safe',
                'track_width_m': 0.210,
                'wheel_diameter_m': 0.0805,
                'counts_per_rev': 4320.0,
                'command_rate_hz': 50.0,
                'cmd_timeout_s': 0.25,
                'imu_yaw_sign': -1.0,
                'publish_tf': True,
            }],
        ),

        # Runs on the Pi so the final LiDAR stop decision does not depend on
        # workstation or Wi-Fi latency.
        Node(
            package='nav2_collision_monitor',
            executable='collision_monitor',
            name='collision_monitor',
            output='screen',
            parameters=[collision_params, {'use_sim_time': use_sim_time}],
        ),

        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_collision_monitor',
            output='screen',
            parameters=[{
                'use_sim_time': use_sim_time,
                'autostart': True,
                'node_names': ['collision_monitor'],
            }],
        ),
    ])
