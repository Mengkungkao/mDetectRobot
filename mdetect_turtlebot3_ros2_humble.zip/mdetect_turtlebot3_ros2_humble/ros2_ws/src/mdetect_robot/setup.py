from setuptools import setup
from glob import glob
import os

package_name = 'mdetect_robot'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Meng Kung Kao',
    maintainer_email='maintainer@example.com',
    description='TurtleBot3-style ROS 2 Humble bringup for the mDetect autonomous robot.',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'serial_bridge = mdetect_robot.serial_bridge:main',
            'waypoint_runner = mdetect_robot.waypoint_runner:main',
        ],
    },
)
