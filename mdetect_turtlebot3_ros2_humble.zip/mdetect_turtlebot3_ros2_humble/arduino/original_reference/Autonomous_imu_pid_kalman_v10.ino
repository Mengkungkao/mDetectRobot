// I made some change in PID different from v9 still not yet better than v9


#include <Wire.h>
#include <avr/pgmspace.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "QGPMaker_MotorShield.h"
#include "QGPMaker_Encoder.h"
#include <MPU6050_tockn.h>

// ---------------- BASIC SETTINGS ----------------

const uint8_t MOTOR_COUNT = 4;
const uint8_t MAX_POINTS = 10;
const uint8_t LINE_BUF_SIZE = 120;

// Motor PWM limits. Tune these values first if the robot is too weak or too fast.
const uint8_t MIN_MOVE_PWM = 50;  // raise if motors hum but do not move
const uint8_t MAX_MOVE_PWM = 120;
const uint8_t TURN_SPEED = 120;
const uint8_t MIN_TURN_SPEED = 90;

// All movement units are now millimetres.
const float WHEEL_DIA_MM = 80.5f;
const float COUNTS_PER_REV = 4320.0f;
const float MM_PER_COUNT = (3.14159f * WHEEL_DIA_MM) / COUNTS_PER_REV;

// Speed profile in mm/s.
const float START_SPEED_MM_S = 50.0f; //80 from start
const float CRUISE_SPEED_MM_S = 100.0f;
const float APPROACH_SPEED_MM_S = 50.0f;

// Distance profile in mm.
const float RAMP_UP_DISTANCE_MM = 500.0f;
const float SLOW_DOWN_DISTANCE_MM = 500.0f;
const float POSITION_TOLERANCE_MM = 2.0f;
const float TURN_TOLERANCE_DEG = 1.0f;

// Simple nonPID heading trim while moving forward
// Positive error slows motors 1 and 4, and speeds up motors 2 and 3
const float HEADING_TRIM_GAIN = 3.0f;  // mm/s per degree
const float MAX_HEADING_TRIM_MM_S = 60.0f;

// Store fixed motor data in flash.
// These values are still useful as feed-forward correction before speed PID trims the final PWM.
const float MOTOR_SCALE[MOTOR_COUNT] PROGMEM = { 0.9069f, 1.0630f, 1.0987f, 0.6170f };
const int8_t ENCODER_SIGN[MOTOR_COUNT] PROGMEM = { -1, 1, 1, -1 };

const uint8_t DIR_CW[MOTOR_COUNT] PROGMEM = { BACKWARD, FORWARD, FORWARD, BACKWARD };
const uint8_t DIR_CCW[MOTOR_COUNT] PROGMEM = { FORWARD, BACKWARD, BACKWARD, FORWARD };

// ---------------- HARDWARE ----------------

QGPMaker_MotorShield AFMS;
QGPMaker_Encoder enc1(1), enc2(2), enc3(3), enc4(4);
MPU6050 mpu6050(Wire);

// ---------------- SMALL DATA TYPES ----------------

struct Waypoint {
  int16_t x;         // mm
  int16_t y;         // mm
  uint16_t waitSec;  // seconds
};

struct MotorSpeedPID {
  float kp;
  float ki;
  float kd;
  float integral;
  float lastError;

  void setGains(float p, float i, float d) {
    kp = p;
    ki = i;
    kd = d;
    reset();
  }

  void reset() {
    integral = 0.0f;
    lastError = 0.0f;
  }

  float compute(float targetSpeed, float measuredSpeed, float dt) {
    if (dt <= 0.0f) return 0.0f;

    float error = targetSpeed - measuredSpeed;
    integral += error * dt;
    integral = constrain(integral, -600.0f, 600.0f);

    float derivative = (error - lastError) / dt;
    lastError = error;

    return (kp * error) + (ki * integral) + (kd * derivative);
  }
};

// ---------------- GLOBAL STATE ----------------

Waypoint waypoints[MAX_POINTS];
uint8_t totalWaypoints = 0;
uint8_t currentWaypoint = 0;

float posX = 0.0f;               // mm
float posY = 0.0f;               // mm
float targetHeading = 0.0f;      // deg
float targetDistance = 0.0f;     // mm
float travelledDistance = 0.0f;  // mm

uint32_t waitStartMs = 0;
uint32_t lastMoveControlMs = 0;

float kfX[MOTOR_COUNT];
float kfP[MOTOR_COUNT];
uint8_t kfReadyMask = 0;

MotorSpeedPID speedPID[MOTOR_COUNT];
float motorPWM[MOTOR_COUNT];
float motorStepMM[MOTOR_COUNT];
float motorSpeedMMs[MOTOR_COUNT];

enum RobotState {
  WAIT_INPUT_POINT,
  TURN_TO_TARGET,
  MOVE_TO_TARGET,
  WAIT_AT_TARGET,
  FINISHED
};

uint8_t state = WAIT_INPUT_POINT;

// ---------------- SMALL HELPERS ----------------

int16_t clampInt16(long v) {
  if (v > 32767L) return 32767;
  if (v < -32768L) return -32768;
  return (int16_t)v;
}

uint16_t clampUInt16(long v) {
  if (v < 0L) return 0;
  if (v > 65535L) return 65535;
  return (uint16_t)v;
}

char *skipSpaces(char *p) {
  while (*p == ' ' || *p == '\t') p++;
  return p;
}

uint8_t scaledSpeed(uint8_t baseSpeed, uint8_t motorIndex) {
  float scale = pgm_read_float(&MOTOR_SCALE[motorIndex]);
  int speedVal = (int)(baseSpeed * scale + 0.5f);
  return (uint8_t)constrain(speedVal, 0, 255);
}

QGPMaker_DCMotor *motor(uint8_t index) {
  return AFMS.getMotor(index + 1);
}

int32_t readEncoderReset(uint8_t index) {
  switch (index) {
    case 0: return enc1.readAndReset();
    case 1: return enc2.readAndReset();
    case 2: return enc3.readAndReset();
    default: return enc4.readAndReset();
  }
}

void setMotor(uint8_t index, uint8_t speedVal, uint8_t dir) {
  QGPMaker_DCMotor *m = motor(index);
  m->setSpeed(scaledSpeed(speedVal, index));
  m->run(dir);
}

void rotateTo(const uint8_t *dirTable, uint8_t speedVal) {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    setMotor(i, speedVal, pgm_read_byte(dirTable + i));
  }
}

void stopMoving() {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    QGPMaker_DCMotor *m = motor(i);
    m->setSpeed(0);
    m->run(RELEASE);
  }
}

void brakeStopMoving() {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    motor(i)->run(BRAKE);
  }

  delay(1000);

  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    QGPMaker_DCMotor *m = motor(i);
    m->setSpeed(0);
    m->run(RELEASE);
  }
}

void resetEncoders() {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    readEncoderReset(i);
  }
}

void resetKalman() {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    kfX[i] = 0.0f;
    kfP[i] = 1.0f;
  }
  kfReadyMask = 0;
}

void initSpeedPID() {
  
    // Start tuning here: increase kp if speed response is slow, increase ki if one motor stays slower.
    // Keep kd small because encoder speed can be noisy.
    speedPID[0].setGains(0.25f, 0.034f, 0.003f);   // motor 1
    speedPID[1].setGains(0.239f, 0.034f, 0.003f);   // motor 2
    speedPID[2].setGains(0.23f, 0.015f, 0.003f);  // motor 3, softer to reduce overshoot
    speedPID[3].setGains(0.25f, 0.034f, 0.003f);   // motor 4
}

void resetSpeedController() {
  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    speedPID[i].reset();
    motorPWM[i] = 0.0f;
    motorStepMM[i] = 0.0f;
    motorSpeedMMs[i] = 0.0f;
  }
  lastMoveControlMs = millis();
}

float kalmanUpdate(uint8_t index, float measurement) {
  const float q = 2.0f;
  const float r = 35.0f;
  uint8_t bit = (1 << index);

  if ((kfReadyMask & bit) == 0) {
    kfX[index] = measurement;
    kfP[index] = 1.0f;
    kfReadyMask |= bit;
    return measurement;
  }

  // Reject very large encoder jumps. This threshold is now in millimetres.
  if (fabs(measurement - kfX[index]) > 150.0f) {
    return kfX[index];
  }

  kfP[index] += q;
  float k = kfP[index] / (kfP[index] + r);
  kfX[index] += k * (measurement - kfX[index]);
  kfP[index] *= (1.0f - k);

  return kfX[index];
}

float getHeadingDeg() {
  return -mpu6050.getAngleZ();
}

float normalizeAngle(float angle) {
  while (angle > 180.0f) angle -= 360.0f;
  while (angle < -180.0f) angle += 360.0f;
  return angle;
}

float getControlDt() {
  uint32_t now = millis();
  float dt = (now - lastMoveControlMs) * 0.001f;
  lastMoveControlMs = now;

  if (dt < 0.005f) dt = 0.005f;
  if (dt > 0.100f) dt = 0.100f;
  return dt;
}

float readDistanceStep(float dt) {
  float sum = 0.0f;

  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    int32_t counts = readEncoderReset(i);
    int8_t sign = (int8_t)pgm_read_byte(&ENCODER_SIGN[i]);

    float rawDistanceMM = counts * sign * MM_PER_COUNT;
    motorStepMM[i] = kalmanUpdate(i, rawDistanceMM);
    motorSpeedMMs[i] = fabs(motorStepMM[i]) / dt;
    sum += motorStepMM[i];
  }

  return sum / MOTOR_COUNT;
}

void updatePose(float localYMM) {
  float thetaRad = getHeadingDeg() * 3.14159f / 180.0f;
  posX += localYMM * sin(thetaRad);
  posY += localYMM * cos(thetaRad);
}

void printPoseLine() {
  Serial.print(posX, 1);
  Serial.print('>');
  Serial.print(posY, 1);
  Serial.print('>');
  Serial.println(getHeadingDeg(), 2);
}

float speedToPWM(float targetSpeedMMs) {
  if (targetSpeedMMs <= 1.0f) return 0.0f;

  float ratio = targetSpeedMMs / CRUISE_SPEED_MM_S;
  ratio = constrain(ratio, 0.0f, 1.0f);

  return MIN_MOVE_PWM + ratio * (MAX_MOVE_PWM - MIN_MOVE_PWM);
}

float targetProfileSpeed(float travelledMM, float remainingMM) {
  if (remainingMM <= POSITION_TOLERANCE_MM) return 0.0f;

  float speed = CRUISE_SPEED_MM_S;

  if (travelledMM < RAMP_UP_DISTANCE_MM) {
    float ratio = travelledMM / RAMP_UP_DISTANCE_MM;
    ratio = constrain(ratio, 0.0f, 1.0f);
    speed = START_SPEED_MM_S + ratio * (CRUISE_SPEED_MM_S - START_SPEED_MM_S);
  }

  if (remainingMM < SLOW_DOWN_DISTANCE_MM) {
    float ratio = remainingMM / SLOW_DOWN_DISTANCE_MM;
    ratio = constrain(ratio, 0.0f, 1.0f);
    float slowSpeed = APPROACH_SPEED_MM_S + ratio * (CRUISE_SPEED_MM_S - APPROACH_SPEED_MM_S);
    if (slowSpeed < speed) speed = slowSpeed;
  }

  return constrain(speed, APPROACH_SPEED_MM_S, CRUISE_SPEED_MM_S);
}

void driveForwardWithSpeedPID(float profileSpeedMMs, float headingErrorDeg, float dt) {
  float headingTrim = headingErrorDeg * HEADING_TRIM_GAIN;
  headingTrim = constrain(headingTrim, -MAX_HEADING_TRIM_MM_S, MAX_HEADING_TRIM_MM_S);

  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    float targetWheelSpeed = profileSpeedMMs;

    if (i == 0 || i == 3) {
      targetWheelSpeed -= headingTrim;
    } else {
      targetWheelSpeed += headingTrim;
    }

    targetWheelSpeed = constrain(targetWheelSpeed, 0.0f, CRUISE_SPEED_MM_S + MAX_HEADING_TRIM_MM_S);

    float basePWM = speedToPWM(targetWheelSpeed);
    float pidTrim = speedPID[i].compute(targetWheelSpeed, motorSpeedMMs[i], dt);

    motorPWM[i] = basePWM + pidTrim;
    motorPWM[i] = constrain(motorPWM[i], 0.0f, 255.0f);

    setMotor(i, (uint8_t)(motorPWM[i] + 0.5f), FORWARD);
  }
}

bool parseWaypoints(char *line) {
  totalWaypoints = 0;
  char *p = line;

  while (totalWaypoints < MAX_POINTS) {
    p = strchr(p, '(');
    if (p == NULL) break;

    char *endPtr;
    long x = strtol(p + 1, &endPtr, 10);
    endPtr = skipSpaces(endPtr);
    if (*endPtr != ',') return false;

    long y = strtol(endPtr + 1, &endPtr, 10);
    endPtr = skipSpaces(endPtr);
    if (*endPtr != ',') return false;

    long waitSec = strtol(endPtr + 1, &endPtr, 10);
    endPtr = skipSpaces(endPtr);
    if (*endPtr != ')') return false;

    waypoints[totalWaypoints].x = clampInt16(x);
    waypoints[totalWaypoints].y = clampInt16(y);
    waypoints[totalWaypoints].waitSec = clampUInt16(waitSec);
    totalWaypoints++;

    p = endPtr + 1;
  }

  currentWaypoint = 0;
  return totalWaypoints > 0;
}

bool readWaypointList() {
  static char line[LINE_BUF_SIZE];
  static uint8_t index = 0;

  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    // Accept newline, carriage return, or ':' as the end of the command.
    // This allows commands such as (-1000,0,0): from Python or Serial Monitor.
    if (c == '\n' || c == '\r' || c == ':') {
      if (index == 0) continue;
      line[index] = '\0';
      index = 0;

      bool ok = parseWaypoints(line);
      if (!ok) {
        Serial.println(F("Invalid waypoint format. Use: (-1000,0,0):"));
      }
      return ok;
    }

    if (index < LINE_BUF_SIZE - 1) {
      line[index++] = c;
    }
  }

  return false;
}

void loadCurrentWaypoint() {
  Waypoint *wp = &waypoints[currentWaypoint];

  travelledDistance = 0.0f;

  float dx = (float)wp->x - posX;
  float dy = (float)wp->y - posY;

  targetDistance = sqrt(dx * dx + dy * dy);
  targetHeading = atan2(dx, dy) * 180.0f / 3.14159f;

  resetEncoders();
  resetKalman();
  resetSpeedController();

  Serial.print(F("Moving to waypoint "));
  Serial.print(currentWaypoint + 1);
  Serial.print(F(" / "));
  Serial.println(totalWaypoints);

  Serial.print(F("Target X: "));
  Serial.print(wp->x);
  Serial.print(F(" mm, Target Y: "));
  Serial.print(wp->y);
  Serial.print(F(" mm, Wait: "));
  Serial.print(wp->waitSec);
  Serial.println(F(" sec"));

  Serial.print(F("Target heading: "));
  Serial.print(targetHeading, 2);
  Serial.print(F(" deg, Target distance: "));
  Serial.print(targetDistance, 1);
  Serial.println(F(" mm"));
}

void printInputHelp() {
  Serial.println("");
  Serial.println(F("Enter waypoint list in millimetres:"));
  Serial.println(F("Example: (0,3000,5) (1000,3000,5) (1000,1000,5) (0,1000,5) (0,0,5)"));
  Serial.println(F("Note: new commands keep the current X/Y position. Reset Arduino to set position back to 0,0."));
}

// ---------------- SETUP ----------------

void setup() {
  Serial.begin(500000);
  Wire.begin();
  AFMS.begin(500);

  for (uint8_t i = 0; i < MOTOR_COUNT; i++) {
    motor(i);
  }

  mpu6050.begin();
  mpu6050.calcGyroOffsets(true);

  initSpeedPID();
  stopMoving();
  resetEncoders();
  resetKalman();
  resetSpeedController();
  printInputHelp();
}

// ---------------- LOOP ----------------

void loop() {
  mpu6050.update();

  switch (state) {
    case WAIT_INPUT_POINT:
      stopMoving();

      if (readWaypointList()) {
        Serial.print(F("Total waypoints loaded: "));
        Serial.println(totalWaypoints);

        // Keep the real-world position from the previous movement.
        // Do not reset posX and posY when a new command is received.
        // Position only goes back to 0,0 after Arduino power/reset.
        currentWaypoint = 0;

        loadCurrentWaypoint();
        Serial.println(F("Rotating to target..."));
        state = TURN_TO_TARGET;
      }
      break;

    case TURN_TO_TARGET:
      {
        float error = normalizeAngle(targetHeading - getHeadingDeg());

        if (fabs(error) > TURN_TOLERANCE_DEG) {
          uint8_t turnSpeed = (uint8_t)constrain((int)(fabs(error) * 2.0f), MIN_TURN_SPEED, TURN_SPEED);

          if (error > 0.0f) {
            rotateTo(DIR_CW, turnSpeed);
          } else if (error < 0.0f) {
            rotateTo(DIR_CCW, turnSpeed);
          }

          printPoseLine();
        } else {
          brakeStopMoving();
          delay(100);

          resetEncoders();
          resetKalman();
          resetSpeedController();

          Serial.println(F("Moving to target..."));
          state = MOVE_TO_TARGET;
        }
        break;
      }

    case MOVE_TO_TARGET:
      {
        float dt = getControlDt();
        float stepMM = readDistanceStep(dt);
        float absStepMM = fabs(stepMM);

        travelledDistance += absStepMM;
        float remainingMM = targetDistance - travelledDistance;
        if (remainingMM < 0.0f) remainingMM = 0.0f;

        updatePose(absStepMM);
        printPoseLine();

        if (remainingMM <= POSITION_TOLERANCE_MM) {
          brakeStopMoving();
          waitStartMs = millis();

          Serial.print(F("Reached waypoint "));
          Serial.print(currentWaypoint + 1);
          Serial.print(F(". Waiting for "));
          Serial.print(waypoints[currentWaypoint].waitSec);
          Serial.println(F(" seconds..."));

          state = WAIT_AT_TARGET;
        } else {
          float profileSpeed = targetProfileSpeed(travelledDistance, remainingMM);
          float headingError = normalizeAngle(targetHeading - getHeadingDeg());
          driveForwardWithSpeedPID(profileSpeed, headingError, dt);
        }
        break;
      }

    case WAIT_AT_TARGET:
      stopMoving();

      if (millis() - waitStartMs >= (uint32_t)waypoints[currentWaypoint].waitSec * 1000UL) {
        state = FINISHED;
      }
      break;

    case FINISHED:
      stopMoving();

      Serial.print(F("Waypoint "));
      Serial.print(currentWaypoint + 1);
      Serial.println(F(" complete."));

      Serial.print(F("Current X: "));
      Serial.print(posX, 1);
      Serial.print(F(" mm   Current Y: "));
      Serial.print(posY, 1);
      Serial.print(F(" mm   Theta: "));
      Serial.print(getHeadingDeg(), 2);
      Serial.println(F(" deg"));

      currentWaypoint++;

      if (currentWaypoint >= totalWaypoints) {
        Serial.println(F("All waypoints completed."));
        printInputHelp();
        state = WAIT_INPUT_POINT;
      } else {
        loadCurrentWaypoint();
        Serial.println(F("Rotating to next target..."));
        state = TURN_TO_TARGET;
      }

      delay(500);
      break;
  }

  delay(5);
}
