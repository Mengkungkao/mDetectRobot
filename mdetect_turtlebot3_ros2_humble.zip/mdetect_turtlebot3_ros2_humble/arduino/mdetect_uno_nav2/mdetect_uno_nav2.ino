/*
 * mDetect Arduino Uno low-level controller for ROS 2 Humble / Nav2.
 *
 * The Uno no longer owns waypoint navigation. ROS 2 sends four signed wheel
 * speed targets at 50 Hz. The Uno closes the encoder speed loops, publishes
 * encoder/IMU telemetry, brakes on stale commands, and owns the hard E-stop
 * latch.
 *
 * Command protocol at 500000 baud:
 *   V,seq,m1_mm_s,m2_mm_s,m3_mm_s,m4_mm_s\n
 *   B,seq\n       brake now
 *   E,seq\n       latch emergency stop
 *   C,seq\n       clear latch (physical E-stop released and targets zero)
 *   Z,seq\n       zero encoder totals and yaw reference
 *
 * Telemetry at 50 Hz:
 *   T,ms,e1,e2,e3,e4,s1,s2,s3,s4,yaw_deg,estop,watchdog\n
 *
 * Existing robot mapping is preserved:
 *   motors 1 and 4 = left side
 *   motors 2 and 3 = right side
 *   positive target speed = FORWARD
 */

#include <Wire.h>
#include <avr/pgmspace.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "QGPMaker_MotorShield.h"
#include "QGPMaker_Encoder.h"
#include <MPU6050_tockn.h>

// ---------------- Configuration ----------------

const uint32_t SERIAL_BAUD = 500000UL;
const uint16_t CONTROL_PERIOD_MS = 20;     // 50 Hz
const uint16_t TELEMETRY_PERIOD_MS = 20;   // 50 Hz
const uint16_t COMMAND_WATCHDOG_MS = 250;
const uint16_t BRAKE_HOLD_MS = 1000;

const uint8_t MOTOR_COUNT = 4;
const float WHEEL_DIAMETER_MM = 80.5f;
const float COUNTS_PER_REV = 4320.0f;
const float MM_PER_COUNT = (3.1415926f * WHEEL_DIAMETER_MM) / COUNTS_PER_REV;

const float MAX_TARGET_SPEED_MM_S = 250.0f;
const uint8_t MIN_MOVE_PWM = 48;
const uint8_t MAX_MOVE_PWM = 190;
const float ZERO_SPEED_DEADBAND_MM_S = 3.0f;

// Keep the existing feed-forward motor compensation. Motor 4 is deliberately
// reduced because it has been observed to run faster than the other motors.
const float MOTOR_SCALE[MOTOR_COUNT] PROGMEM = {
  0.9069f, 1.0630f, 1.0987f, 0.6170f
};

// Direction-correct encoder polarity for positive robot-forward motion.
const int8_t ENCODER_SIGN[MOTOR_COUNT] PROGMEM = { -1, 1, 1, -1 };

// Physical emergency-stop input. Connect a normally-closed switch between
// A0 and GND. Opening/pressing the switch makes the input HIGH and latches stop.
// Set ESTOP_ACTIVE_LEVEL to LOW instead when using a normally-open switch.
const uint8_t ESTOP_PIN = A0;
const uint8_t ESTOP_ACTIVE_LEVEL = HIGH;

// ---------------- Hardware ----------------

QGPMaker_MotorShield AFMS;
QGPMaker_Encoder enc1(1), enc2(2), enc3(3), enc4(4);
MPU6050 mpu6050(Wire);

// ---------------- PID ----------------

struct SpeedPID {
  float kp;
  float ki;
  float kd;
  float integral;
  float previousError;

  void set(float p, float i, float d) {
    kp = p;
    ki = i;
    kd = d;
    reset();
  }

  void reset() {
    integral = 0.0f;
    previousError = 0.0f;
  }

  float update(float targetMagnitude, float measuredMagnitude, float dt) {
    if (dt <= 0.0f) return 0.0f;
    float error = targetMagnitude - measuredMagnitude;
    integral += error * dt;
    integral = constrain(integral, -500.0f, 500.0f);
    float derivative = (error - previousError) / dt;
    previousError = error;
    return kp * error + ki * integral + kd * derivative;
  }
};

SpeedPID pid[MOTOR_COUNT];

// ---------------- State ----------------

float targetSpeedMMs[MOTOR_COUNT] = { 0, 0, 0, 0 };
float measuredSpeedMMs[MOTOR_COUNT] = { 0, 0, 0, 0 };
float filteredSpeedMMs[MOTOR_COUNT] = { 0, 0, 0, 0 };
int32_t encoderTotal[MOTOR_COUNT] = { 0, 0, 0, 0 };
uint8_t appliedPWM[MOTOR_COUNT] = { 0, 0, 0, 0 };

uint32_t lastControlMs = 0;
uint32_t lastTelemetryMs = 0;
uint32_t lastValidCommandMs = 0;
uint32_t brakeStartMs = 0;

bool estopLatched = false;
bool watchdogActive = true;
bool brakeActive = true;
float yawZeroDeg = 0.0f;

const uint8_t RX_BUFFER_SIZE = 96;
char rxBuffer[RX_BUFFER_SIZE];
uint8_t rxIndex = 0;

// ---------------- Hardware helpers ----------------

QGPMaker_DCMotor *motor(uint8_t index) {
  return AFMS.getMotor(index + 1);
}

int32_t readEncoderResetAtomic(uint8_t index) {
  noInterrupts();
  int32_t value;
  switch (index) {
    case 0: value = enc1.readAndReset(); break;
    case 1: value = enc2.readAndReset(); break;
    case 2: value = enc3.readAndReset(); break;
    default: value = enc4.readAndReset(); break;
  }
  interrupts();
  return value;
}

uint8_t scaledPWM(uint8_t pwm, uint8_t index) {
  float scale = pgm_read_float(&MOTOR_SCALE[index]);
  return (uint8_t)constrain((int)(pwm * scale + 0.5f), 0, 255);
}

void applyMotor(uint8_t index, float signedTarget, uint8_t pwm) {
  QGPMaker_DCMotor *m = motor(index);
  uint8_t direction = signedTarget >= 0.0f ? FORWARD : BACKWARD;
  m->run(direction);                 // set a known direction first
  m->setSpeed(scaledPWM(pwm, index));
}

void brakeAll() {
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    motor(i)->run(BRAKE);
    appliedPWM[i] = 0;
  }
}

void releaseAll() {
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    QGPMaker_DCMotor *m = motor(i);
    m->setSpeed(0);
    m->run(RELEASE);
    appliedPWM[i] = 0;
  }
}

void beginBrakeHold() {
  brakeActive = true;
  brakeStartMs = millis();
  brakeAll();
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) pid[i].reset();
}

void setTargetsZero() {
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) targetSpeedMMs[i] = 0.0f;
}

bool allTargetsZero() {
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    if (fabs(targetSpeedMMs[i]) > ZERO_SPEED_DEADBAND_MM_S) return false;
  }
  return true;
}

float speedToFeedForwardPWM(float targetMagnitude) {
  if (targetMagnitude <= ZERO_SPEED_DEADBAND_MM_S) return 0.0f;
  float ratio = constrain(targetMagnitude / MAX_TARGET_SPEED_MM_S, 0.0f, 1.0f);
  return MIN_MOVE_PWM + ratio * (MAX_MOVE_PWM - MIN_MOVE_PWM);
}

// ---------------- Safety ----------------

bool physicalEstopActive() {
  return digitalRead(ESTOP_PIN) == ESTOP_ACTIVE_LEVEL;
}

void latchEmergencyStop() {
  estopLatched = true;
  setTargetsZero();
  beginBrakeHold();
}

void updateSafety() {
  if (physicalEstopActive()) {
    latchEmergencyStop();
  }

  uint32_t now = millis();
  if ((uint32_t)(now - lastValidCommandMs) > COMMAND_WATCHDOG_MS) {
    if (!watchdogActive) beginBrakeHold();
    watchdogActive = true;
    setTargetsZero();
  }
}

// ---------------- Encoder and control ----------------

void updateEncoderSpeeds(float dt) {
  const float alpha = 0.35f;

  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    int32_t raw = readEncoderResetAtomic(i);
    int8_t sign = (int8_t)pgm_read_byte(&ENCODER_SIGN[i]);
    int32_t corrected = raw * sign;
    encoderTotal[i] += corrected;

    float speed = corrected * MM_PER_COUNT / dt;
    measuredSpeedMMs[i] = speed;
    filteredSpeedMMs[i] = alpha * speed + (1.0f - alpha) * filteredSpeedMMs[i];
  }
}

void runSpeedControllers(float dt) {
  if (estopLatched || watchdogActive) {
    brakeAll();
    return;
  }

  if (allTargetsZero()) {
    if (!brakeActive) beginBrakeHold();

    if ((uint32_t)(millis() - brakeStartMs) < BRAKE_HOLD_MS) {
      brakeAll();
    } else {
      releaseAll();
    }
    return;
  }

  brakeActive = false;

  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    float target = constrain(targetSpeedMMs[i], -MAX_TARGET_SPEED_MM_S, MAX_TARGET_SPEED_MM_S);
    float targetMagnitude = fabs(target);

    if (targetMagnitude <= ZERO_SPEED_DEADBAND_MM_S) {
      motor(i)->run(BRAKE);
      appliedPWM[i] = 0;
      pid[i].reset();
      continue;
    }

    float measuredMagnitude = fabs(filteredSpeedMMs[i]);
    float pwm = speedToFeedForwardPWM(targetMagnitude)
              + pid[i].update(targetMagnitude, measuredMagnitude, dt);
    pwm = constrain(pwm, 0.0f, 255.0f);
    appliedPWM[i] = (uint8_t)(pwm + 0.5f);
    applyMotor(i, target, appliedPWM[i]);
  }
}

// ---------------- Serial protocol ----------------

void sendAck(const char *code, uint16_t sequence) {
  Serial.print(F("A,"));
  Serial.print(sequence);
  Serial.print(',');
  Serial.println(code);
}

bool parseLongToken(char *token, long &value) {
  if (token == NULL || *token == '\0') return false;
  char *endPtr = NULL;
  value = strtol(token, &endPtr, 10);
  return endPtr != token && *endPtr == '\0';
}

void processCommand(char *line) {
  char *savePtr = NULL;
  char *command = strtok_r(line, ",", &savePtr);
  char *seqToken = strtok_r(NULL, ",", &savePtr);
  long seqLong = 0;

  if (command == NULL || !parseLongToken(seqToken, seqLong)) {
    Serial.println(F("ERR,FORMAT"));
    return;
  }
  uint16_t sequence = (uint16_t)seqLong;

  if (strcmp(command, "V") == 0) {
    float newTargets[MOTOR_COUNT];
    for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
      char *token = strtok_r(NULL, ",", &savePtr);
      long speedLong = 0;
      if (!parseLongToken(token, speedLong)) {
        Serial.println(F("ERR,V_FORMAT"));
        return;
      }
      newTargets[i] = constrain((float)speedLong,
                                -MAX_TARGET_SPEED_MM_S,
                                MAX_TARGET_SPEED_MM_S);
    }

    if (strtok_r(NULL, ",", &savePtr) != NULL) {
      Serial.println(F("ERR,V_EXTRA"));
      return;
    }

    if (!estopLatched) {
      for (uint8_t i = 0; i < MOTOR_COUNT; ++i) targetSpeedMMs[i] = newTargets[i];
    } else {
      setTargetsZero();
    }
    lastValidCommandMs = millis();
    watchdogActive = false;
    sendAck("V", sequence);
    return;
  }

  if (strcmp(command, "B") == 0) {
    setTargetsZero();
    beginBrakeHold();
    lastValidCommandMs = millis();
    watchdogActive = false;
    sendAck("B", sequence);
    return;
  }

  if (strcmp(command, "E") == 0) {
    latchEmergencyStop();
    sendAck("E", sequence);
    return;
  }

  if (strcmp(command, "C") == 0) {
    if (!physicalEstopActive() && allTargetsZero()) {
      estopLatched = false;
      lastValidCommandMs = millis();
      watchdogActive = false;
      beginBrakeHold();
      sendAck("C", sequence);
    } else {
      Serial.print(F("ERR,"));
      Serial.print(sequence);
      Serial.println(F(",C_DENIED"));
    }
    return;
  }

  if (strcmp(command, "Z") == 0) {
    for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
      readEncoderResetAtomic(i);
      encoderTotal[i] = 0;
      filteredSpeedMMs[i] = 0.0f;
      measuredSpeedMMs[i] = 0.0f;
      pid[i].reset();
    }
    yawZeroDeg = -mpu6050.getAngleZ();
    sendAck("Z", sequence);
    return;
  }

  Serial.println(F("ERR,UNKNOWN"));
}

void readSerialCommands() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    if (c == '\n' || c == '\r') {
      if (rxIndex > 0) {
        rxBuffer[rxIndex] = '\0';
        processCommand(rxBuffer);
        rxIndex = 0;
      }
      continue;
    }

    if (rxIndex < RX_BUFFER_SIZE - 1) {
      rxBuffer[rxIndex++] = c;
    } else {
      rxIndex = 0;
      Serial.println(F("ERR,OVERFLOW"));
    }
  }
}

void publishTelemetry() {
  float yawDeg = -mpu6050.getAngleZ() - yawZeroDeg;
  while (yawDeg > 180.0f) yawDeg -= 360.0f;
  while (yawDeg < -180.0f) yawDeg += 360.0f;

  Serial.print(F("T,"));
  Serial.print(millis());
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    Serial.print(',');
    Serial.print(encoderTotal[i]);
  }
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) {
    Serial.print(',');
    Serial.print(filteredSpeedMMs[i], 1);
  }
  Serial.print(',');
  Serial.print(yawDeg, 2);
  Serial.print(',');
  Serial.print(estopLatched ? 1 : 0);
  Serial.print(',');
  Serial.println(watchdogActive ? 1 : 0);
}

// ---------------- Setup and loop ----------------

void setup() {
  Serial.begin(SERIAL_BAUD);
  pinMode(ESTOP_PIN, INPUT_PULLUP);

  Wire.begin();
  AFMS.begin(500);
  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) motor(i);

  mpu6050.begin();
  mpu6050.calcGyroOffsets(true);
  mpu6050.update();
  yawZeroDeg = -mpu6050.getAngleZ();

  // Begin with conservative gains; tune each motor from measured telemetry.
  pid[0].set(0.25f, 0.034f, 0.003f);
  pid[1].set(0.239f, 0.034f, 0.003f);
  pid[2].set(0.23f, 0.015f, 0.003f);
  pid[3].set(0.25f, 0.034f, 0.003f);

  for (uint8_t i = 0; i < MOTOR_COUNT; ++i) readEncoderResetAtomic(i);
  setTargetsZero();
  beginBrakeHold();
  lastControlMs = millis();
  lastTelemetryMs = millis();
  lastValidCommandMs = millis();

  Serial.println(F("BOOT,MDETECT_UNO_NAV2,1"));
}

void loop() {
  mpu6050.update();
  readSerialCommands();
  updateSafety();

  uint32_t now = millis();
  if ((uint32_t)(now - lastControlMs) >= CONTROL_PERIOD_MS) {
    float dt = (now - lastControlMs) * 0.001f;
    lastControlMs = now;
    if (dt > 0.1f) dt = 0.1f;
    updateEncoderSpeeds(dt);
    runSpeedControllers(dt);
  }

  if ((uint32_t)(now - lastTelemetryMs) >= TELEMETRY_PERIOD_MS) {
    lastTelemetryMs = now;
    publishTelemetry();
  }
}
